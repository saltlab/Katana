import React, { Component } from 'react';
import Form from './Form';
class App extends Component {
  render() {
    return React.createElement("div", {
      className: "homepage"
    }, React.createElement("p", null, "Welcome to Penn Course Recs"), React.createElement(Form, null));
  }
}
