var getJSON = require('get-json');
var CronJob = require('cron').CronJob;
new CronJob('*/4 * * * * *', function() {

  getJSON(`https://yaroslav-andreev.ru/megabot/megabot.php?heroku&send_msg`).then(function(response) {
    //console.clear();
    //console.log(response);
 }).catch(function(error) {console.log(error);});
}, null, true, 'Europe/Moscow');
