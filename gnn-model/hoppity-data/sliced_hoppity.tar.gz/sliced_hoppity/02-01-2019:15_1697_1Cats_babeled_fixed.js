import React, { Component } from 'react';
import Select from 'react-select';
class Cats extends Component {
  render() {
    return React.createElement(React.Fragment, null, React.createElement("div", null, React.createElement("h2", {
    }, "Cat Breed Selector")), React.createElement("div", {
    }, React.createElement(Select, {
      className: "cat-selector",
    })));
  }
}
