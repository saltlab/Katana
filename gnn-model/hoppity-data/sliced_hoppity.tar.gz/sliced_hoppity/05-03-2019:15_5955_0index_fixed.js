class Formatter {
  static sanitize(str){
    let newStr = str.replace(/[^-,^' ',^,A-Za-z0-9]+/g, '');
    }
}
