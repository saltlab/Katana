'use strict'
// Template version: 1.3.1
// see http://vuejs-templates.github.io/webpack for documentation.
const path = require('path')
var assetspp = '';
if(process.env.LINX_AGENT == 'electron') {
  assetspp = './';
} else {
  assetspp = '/';
}

module.exports = {
  dev: {

    // Paths
    env: require('./dev.env'),
    assetsSubDirectory: 'static',
    assetsPublicPath: assetspp,
    proxyTable: {},

    // Various Dev Server settings
    host: 'localhost', // can be overwritten by process.env.HOST
    port: 8080, // can be overwritten by process.env.PORT, if port is in use, a free one will be determined
    autoOpenBrowser: false,
    errorOverlay: true,
    notifyOnErrors: true,
    poll: false, // https://webpack.js.org/configuration/dev-server/#devserver-watchoptions-

    // Use Eslint Loader?
    // If true, your code will be linted during bundling and
    // linting errors and warnings will be shown in the console.
    useEslint: false,
  },
}
