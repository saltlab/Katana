export const STATE_MAPPING_SERVICE = {
  '/sms/{serviceName}': {
    state: 'sms.service.dashboard',
    stateParams: {
      serviceName: 'resource.name',
    },
  },
  '/overTheBox/{serviceName}': {
    state: 'overTheBox.details',
    stateParams: {
      serviceName: 'resource.name',
    },
  },
  '/freefax/{serviceName}': {
    state: 'freefax',
    prefix: 'sidebar_section_fax_prefix_freefax',
    stateParams: {
      serviceName: 'resource.name',
    },
  },
  '/telephony/{billingAccount}': {
    state: 'telephony',
    stateParams: {
      billingAccount: 'resource.name',
    },
  },
  default: {
    state: 'welcome',
    prefix: '',
    stateParams: {},
  },
};
