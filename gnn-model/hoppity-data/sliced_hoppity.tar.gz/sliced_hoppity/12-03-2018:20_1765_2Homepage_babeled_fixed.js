import React, { Component } from 'react';
class Homepage extends Component {
  render() {
    return React.createElement("div", null, React.createElement("h1", null, "Welcome to homepage"), React.createElement("p", null, "homepage"));
  }
}
