import React from "react";
import SginInHeader from "./layouts/SginInHeader";
import SginOutHeader from "./layouts/SginOutHeader";
const Header = () => React.createElement("header", {
  className: "App-header"
}, React.createElement("h1", {
  className: "App-title"
}, React.createElement(Link, {
  to: "/",
  className: "App-title"
}, "Garage Search")), React.createElement(SginOutHeader, null), React.createElement(SginInHeader, null));
