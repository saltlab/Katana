self.console.log = function proxyConsole(...args) {
  self.__logs = [...self.__logs, ...args];
};
onmessage = async e => {
  self.__logs = [];
  const assert = chai.assert;
  try {
    self.postMessage({ pass: true, logs: self.__logs.map(String) });
  } catch (err) {
    self.postMessage({
      err: {
        isAssertionError: err instanceof chai.AssertionError
      },
    });
  }
};
