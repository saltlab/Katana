import React from 'react';
import Kitchen from './kitchen';
export class Dashboard extends React.Component {
  render() {
    return React.createElement("div", {
    }, React.createElement("h1", {
    }, this.props.name, "'s Kitchen"), React.createElement(Kitchen, null));
  }
}
