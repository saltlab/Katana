const express = require('express');
const app = express();
require('../src/app/controllers/index')(app);
