'use strict';

describe('Controller: SearchCtrl', function () {

  // load the controller's module
  beforeEach(module('bhcmartApp'));
});
