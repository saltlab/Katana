import CompressionPlugin from 'compression-webpack-plugin';
export default {
  plugins: [
    new CompressionPlugin({
      test: /\.js$|\.css$|\.html$/,
    })
  ],
};
