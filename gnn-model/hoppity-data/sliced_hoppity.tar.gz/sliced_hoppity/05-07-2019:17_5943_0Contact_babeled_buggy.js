import React from "react";
function Contact() {
  return React.createElement(Wrapper, null, React.createElement(LinkWrapper, null, React.createElement("a", {
    href: "mailto:miloslavc90@gmail.com",
    rel: "noopener noreferrer"
  }, "Email me"), React.createElement("a", {
    target: "_black",
    href: "https://codepen.io/miloslavc/",
    rel: "noopener noreferrer"
  }, "CodePen"), React.createElement("a", {
    target: "_black",
    href: "https://github.com/miloslavc",
    rel: "noopener noreferrer"
  }, "GitHub"), React.createElement("a", {
    target: "_black",
    href: "https://www.linkedin.com/in/miloslavc/",
    rel: "noopener noreferrer"
  }, "LinkedIn")), React.createElement(TextWrapper, null, "Made with", React.createElement("span", {
    role: "img",
    "aria-label": "Heart"
  }, "\u2665"), "by Miloslav Cvetkovic"));
}
