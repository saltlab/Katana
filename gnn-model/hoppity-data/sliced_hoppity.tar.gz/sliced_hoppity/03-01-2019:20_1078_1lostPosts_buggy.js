var express = require('express');
var router = express.Router();
router.get('/', function(req, res, next) {
  const query = {
    name: 'Get lost posts',
    text: "SELECT * from lost_items where status = 'missing'"
    // values: [req.body.email]
  }
});
