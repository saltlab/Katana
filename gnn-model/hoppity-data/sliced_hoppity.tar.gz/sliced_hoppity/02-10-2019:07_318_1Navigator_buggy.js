const AppStackNavigator = createStackNavigator({
  }, {
    initialRouteName: 'Location'
  });
