import React from "react";
export class Pets extends React.Component {
  componentDidMount() {
    console.log("hi");
  }
}
