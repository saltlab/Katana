var express = require("express");
var router = express.Router();
router.get("/room/:type/:id", function(req, res) {
  var id=req.params.id;
  var type=req.params.type;
  res.render("course", { id:id,type,tpype });
});
