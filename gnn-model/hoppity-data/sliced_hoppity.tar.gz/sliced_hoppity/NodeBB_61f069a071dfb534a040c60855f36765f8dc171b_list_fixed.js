	assert = require('assert'),
	db = require('../mocks/databasemock');
describe('List methods', function() {
	describe('listRemoveLast()', function() {
		it('should remove the last element of list and return it', function(done) {
			db.listRemoveLast('testList4', function(err, lastElement) {
			});
		});
	});
});
