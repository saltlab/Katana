const Discord = require('discord.js');

exports.run = (bot, message, args) => {
    if(message.member.voiceChannel) {

        if(message.guild.voiceConnection){

            message.member.voiceChannel.join()
                 .then(connection => {
                     message.channel.send("I'm here");
                 })
        }
    }
};
