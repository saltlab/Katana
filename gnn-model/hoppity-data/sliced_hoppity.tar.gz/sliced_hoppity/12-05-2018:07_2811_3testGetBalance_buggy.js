import fastx from "./config";
const testBalance = async () => {
    const address = fastx.defaultAccount;
    let res = (await fastx.getEthBalance(address));
};
