describe('valid.isSafeString', function() {
    var tests = ['a', '$', '£', '€', '∑']
    it('should be a safe string: ' + tests[2], function() {
    })
});
