describe("<Password />", () => {
  let props;
  it("renders correctly", () => {
    props = {
      minPassLen: 8,
    };
  });
});
