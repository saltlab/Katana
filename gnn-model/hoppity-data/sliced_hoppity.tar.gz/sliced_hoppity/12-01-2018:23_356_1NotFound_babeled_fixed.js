import React, { Component } from 'react';
class NotFound extends Component {
  render() {
    return React.createElement("section", {
      className: "NotFound"
    }, React.createElement("h2", null, "Page not found, sorry!"));
  }
}
