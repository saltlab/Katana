function license() {
    var sys = require('../modules/sys')
    sys.stdout.write('LICENSE file is available at https://github.com/pybee/batavia/blob/master/LICENSE\n')
}
