export const testUnits = ({ units }, testCall) => {
    var _units = parseInt(units);
}
