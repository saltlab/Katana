var express = require("express");
var routes = express.Router();
var category = require("../../models/category");
routes.post("/", function(req, res ){
	category.insert(req.body, function (err, result){
		res.redirect("/admin/addcategory");
	});
});
