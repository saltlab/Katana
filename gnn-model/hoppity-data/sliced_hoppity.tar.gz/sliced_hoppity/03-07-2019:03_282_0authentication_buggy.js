    class Auth {
      constructor() {
        this.auth0 = new auth0.WebAuth({
          domain: 'kingeric.auth0.com',
          audience: 'https://kingeric.auth0.com/userinfo',
          clientID: 'RgypgNKbpL15E9tPKlmrOYbnEGfaX9UJ',
          redirectUri: 'http://localhost:3000/callback',
          responseType: 'id_token',
          scope: 'openid profile'
        });
        this.handleAuthentication = this.handleAuthentication.bind(this);
      }
      handleAuthentication() {
        return new Promise((resolve, reject) => {
          this.auth0.parseHash((err, authResult) => {
            if (err) return reject(err);
            this.expiresAt = authResult.idTokenPayload.exp * 1000;
          });
        })
      }
    }
