import React from 'react';
import config from '../../config';
import Button from '../../components/Button';
import Typography, { TypoWeight, TypoVariants } from '../../components/Typography';
import imgPrototypingProcess from '../../assets/img/prototyping-process.svg';
import styles from './Home.module.css';
const Home = () => {
  return React.createElement("div", {
    className: "container"
  }, React.createElement("div", {
    className: "row"
  }, React.createElement("div", {
    className: "col-md-2"
  }, React.createElement("div", {
    className: styles.wrapper
  }, React.createElement("div", {
    className: styles.container
  }, React.createElement(Typography, {
    className: styles.heading,
    weight: TypoWeight.semibold
  }, "Inside", React.createElement("br", null), "out"), React.createElement(Typography, {
    className: styles.subHeading,
    variant: TypoVariants.h2,
    weight: TypoWeight.light
  }, "International conference ", React.createElement("br", null), " on illusstraion"), React.createElement(Typography, {
    className: styles.location,
    variant: TypoVariants.h4,
    weight: TypoWeight.semibold
  }, "2019, September 25 - 28", React.createElement("br", null), " VNU University of Science, HCMC"), React.createElement("div", {
    className: styles.btnRegister
  }, React.createElement(Button, {
    href: config.paths.registration
  }, "Register Now"))))), React.createElement("div", {
    className: "col-md-2"
  }, React.createElement("div", {
    className: styles.wrapperIllustration
  }, React.createElement("img", {
    className: styles.illustration,
    src: imgPrototypingProcess,
    alt: "Prototyping Process"
  })))));
};
