import graphqlClient  from 'graphql-client'
const client = graphqlClient({
})
export const getRepositoryInfo = repository => client.query(`
query {
  repository(name:"${repository}", owner:"wolox-training") {
  }
}`, null, null)
