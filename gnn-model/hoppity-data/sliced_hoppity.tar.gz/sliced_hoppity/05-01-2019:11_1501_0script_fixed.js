const switchMenu = () => {
    const bars = document.querySelector("nav > ul");
    bars.classList.toggle("menu--active");
};

const calculateMenuSize = () => {
    const menuItems = document.querySelectorAll("nav a > li");
    const menuItemSize = (window.outerHeight - 50) / (menuItems.length - 1);
};
