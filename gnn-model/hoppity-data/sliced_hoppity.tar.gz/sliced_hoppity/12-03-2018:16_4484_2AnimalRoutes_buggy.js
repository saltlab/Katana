const express = require('express');
const PMs = require('./AnimalMiddlewares');
const AuthM = require('../../AuthMiddlewares');
const animalRouter = express.Router();
animalRouter.route('/:animalId')
    .get(PMs.afficherUnAnimal)
    .post(AuthM.hasValidAuthorizationToken, PMs.mettreAJourUnAnimal)
    .delete(AuthM.hasValidAuthorizationToken, PMs.supprimerUnAnimal);
