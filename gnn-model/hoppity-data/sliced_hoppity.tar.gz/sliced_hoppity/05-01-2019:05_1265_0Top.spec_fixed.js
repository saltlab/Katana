import Vuex from 'vuex'
import Top from '../../../src/components/Top'
const localVue = createLocalVue();
describe('Top.vue', () => {
  let store
  beforeEach(() => {
    store = new Vuex.Store({
    })
  })
  it('test of getters and actions', () => {
    const wrapper = shallowMount(Top, {store, localVue})
    const button = wrapper.find('.delete-button')
  })
})
