let store = { deliveries: [], meals: [], customers: [], employers: []}
class Customer {
  totalSpent() {
    store.deliveries.filter(function() {
      return this.id === delivery.customerId;
    }).bind(this)
  }
}
