import React, { Component } from 'react';
class LinneHeader extends Component {
  render() {
    return React.createElement("div", {
      className: "App"
    }, React.createElement("header", null, React.createElement("h1", null, "Linne Final Project")));
  }
}
