class Projects extends Component {
  componentDidMount() {
    var xhttp = new XMLHttpRequest();
    xhttp.open('GET', 'http://localhost:3000/projectPreviews', true);
  }
}
