var Enquirer = require('enquirer');
var enquirer = new Enquirer();
enquirer.question('token', 'Bot Token: ');
