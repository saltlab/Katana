import React from 'react';
import Layout from '../components/Layout';
export default class IndexPage extends React.Component {
  render() {
    return React.createElement(Layout, null, "Test");
  }
}
