import React from 'react';
const ImageList = props => {
  const images = props.images.map(({
    description,
    id,
    urls
  }) => {
    return React.createElement("img", {
      src: urls.regular,
      key: id,
      alt: description
    });
  });
  return React.createElement("div", null, images, " this is still working");
};
