class Throw extends Trait {
    constructor() {
        this.dir = 0;
        this.speed = 200;  //should be about 10,000
    }
    update(entity, deltaTime) {
        entity.vel.x = this.speed * this.dir * deltaTime;
    }
}
