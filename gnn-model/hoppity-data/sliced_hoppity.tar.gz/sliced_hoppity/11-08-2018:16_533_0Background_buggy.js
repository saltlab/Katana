export default class Background {
  constructor(id) {
    this.modelo = new Image();
    this.modelo.src = '../images/bg.png';
  }
}
