import BroadcastService from "@/services/modules/broadcast.service";
export default {
  async created() {
    let result = await BroadcastService.index();
  },
};
