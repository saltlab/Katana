import React from 'react';
class UITabSortableDetailColumns extends React.PureComponent {
  render() {
    let torrentDetailItems = this.props.torrentDetails.slice();
    if (this.props.torrentListViewSize === 'expanded') {
      torrentDetailItems = torrentDetailItems.reduce((accumulator, detail, index) => {
      }, []);
    }
  }
}
