const { spawnSync } = require('child_process');
const syntaxArgs = [
];
syntaxArgs.forEach(function(arg) {
  const c = spawnSync(
    ['--experimental-modules', '--no-warnings', '--input-type=module', arg],
  );
});
