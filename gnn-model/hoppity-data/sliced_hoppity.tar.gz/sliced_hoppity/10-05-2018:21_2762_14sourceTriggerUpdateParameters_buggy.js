class SourceTriggerUpdateParameters {
  mapper() {
    return {
      type: {
        modelProperties: {
          sourceTriggerEvents: {
            type: {
              element: {
                  serializedName: 'SourceTriggerEventElementType',
              }
            }
          },
        }
      }
    };
  }
}
