//[Data Table Javascript]
//Primary use:   Used only for the Data Table
$(function () {
    "use strict";
    $('#example2').DataTable({
      'paging'      : true,
      'lengthChange': false,
      'searching'   : false,
    });

    $('#example5 tfoot th').each( function () {
        var title = $(this).text();
        $(this).html( '<input type="text" placeholder="Pesquisar '+title+'" />' );
    } );
  }); // End of use strict
