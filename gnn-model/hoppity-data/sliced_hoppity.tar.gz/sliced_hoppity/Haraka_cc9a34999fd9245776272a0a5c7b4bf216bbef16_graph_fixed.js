// log our denys

var http  = require('http');
var urlp  = require('url');
var utils = require('./utils');

var db;
var select = "SELECT COUNT(*) AS hits, plugin FROM graphdata WHERE timestamp >= ? AND timestamp < ? GROUP BY plugin";
var insert;
var plugins = {};
var config;

var width = 800;

function createTable() {
    db.exec( "CREATE TABLE IF NOT EXISTS graphdata (timestamp INTEGER NOT NULL, plugin TEXT NOT NULL)")
      .exec( "CREATE INDEX IF NOT EXISTS graphdata_idx ON graphdata (timestamp)");
}

exports.register = function () {
    var plugin = this;
    config  = plugin.config.get('graph.ini');
    var ignore_re = config.main.ignore_re || plugin.config.get('grapher.ignore_re') || 'queue|graph|relay';
    ignore_re = new RegExp(ignore_re);

    plugins = {accepted: 0, disconnect_early: 0};

    plugin.config.get('plugins', 'list').forEach(
        function (p) {
            if (!p.match(ignore_re)) {
                plugins[p] = 0;
            }
        }
    );

    try {
        var sqlite3 = require('sqlite3').verbose();
    }
    catch (e) {
        plugin.logerror("unable to load sqlite3, try\n\n\t'npm install -g sqlite3'\n\n");
        return;
    }

    var db_name = config.main.db_file || 'graphlog.db';
    db = new sqlite3.Database(db_name, createTable);
    insert = db.prepare( "INSERT INTO graphdata VALUES (?,?)" );

    plugin.register_hook('init_master',   'http_init');
    plugin.register_hook('disconnect',    'disconnect');
    plugin.register_hook('deny',          'deny');
    plugin.register_hook('queue_ok',      'queue_ok');
};

exports.http_init = function (next) {
    var plugin = this;
    var port   = config.main.http_port || this.config.get('grapher.http_port') || 8080;
    var addr   = config.main.http_addr || '127.0.0.1';
    var server = http.createServer(
        function (req, res) {
            plugin.handle_http_request(req, res);
        });

    server.on('error', function (err) {
        plugin.logerror("http server failed to start. Maybe running elsewhere?" + err);
        next(DENY);
    });

    server.listen(port, addr, function () {
        plugin.loginfo("http server running on " + addr + ':' + port);
        next();
    });
};

exports.disconnect = function (next, connection) {
    if (!connection.current_line) {
        // disconnect without saying anything
        return this.hook_deny(next, connection, [DENY, "random disconnect", "disconnect_early"]);
    }
    next();
};

exports.deny = function (next, connection, params) {
    var plugin = this;
    insert.bind([new Date().getTime(), params[2]], function (err) {
        if (err) {
            plugin.logerror("Insert DENY failed: " + err);
            return next();
        }
        insert.run(function (err, rows) {
            if (err) {
                plugin.logerror("Insert failed: " + err);
            }
            try { insert.reset(); } catch (e) {}
            next();
        });
    });
};

exports.queue_ok = function (next, connection, params) {
    var plugin = this;
};
