function nowServing(katzDeliLine){
  katzDeliLine.shift();
}
