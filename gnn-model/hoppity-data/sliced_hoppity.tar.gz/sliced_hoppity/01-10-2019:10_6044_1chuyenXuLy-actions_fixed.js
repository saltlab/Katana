export const getListGroupUnitSucessAction = (response) => {
    return{
        listGroupUnit: response,
    }
}
