import React, { Component } from "react";
import CssBaseline from "@material-ui/core/CssBaseline";
class Registration extends Component {
  render() {
    return React.createElement("div", null, React.createElement(CssBaseline, null), "Registration Form changeMe!!");
  }
}
