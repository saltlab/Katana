import Vue from 'vue'
import App from './App'
import router from './router/index.js'
import ElementUI from 'element-ui'
import '../node_modules/element-ui/lib/theme-chalk/index.css'

Vue.prototype.fromFlag = false;//本地或者数据库标志,//true为真实数据，false为本地数据
