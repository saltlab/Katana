import React from 'react';
import MainButton from './MainButton.js';
import Calendar from './calendar';
import DropDownTasks from './DropDownTasks';
const Home = props => {
  return React.createElement("div", {
    class: "container"
  }, React.createElement("div", {
    className: "section center-align"
  }, React.createElement("h3", null, "When do you need, Momma?"), React.createElement(Calendar, {
    clickDate: props.clickDate,
    name: props.name,
    date: props.date,
    datePicked: props.datePicked
  })), React.createElement("br", null), React.createElement("br", null), React.createElement("div", {
    className: "section center-align"
  }, props.namePicked ? React.createElement("p", {
    className: "center-align"
  }, "Selected Task:  ", props.name) : React.createElement(DropDownTasks, {
    options: props.options,
    selectTask: props.selectTask,
    name: props.name,
    namePicked: props.namePicked
  })), React.createElement("br", null), React.createElement("br", null), React.createElement("div", {
    className: "section center-align"
  }, React.createElement(MainButton, {
    setTask: props.setTask
  })));
};
