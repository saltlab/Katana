$(function() {
  $('.send').on('click', function() {
    const _from = $('#from_list').val()
    const _to = $('#to_list').val()
    const _value = $('#value').val()
    axios
      .post('/api/send-coin', { from: _from, to: _to, value: _value })
      .then(resp => {
        $('#report').append($('#report_tmpl').render(resp.data))
      })
  })
})
