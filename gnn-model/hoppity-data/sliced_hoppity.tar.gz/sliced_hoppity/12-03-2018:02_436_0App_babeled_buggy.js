import React, { Component } from "react";
import OtherProfile from "./OtherProf"; // export default class App
const App = () => React.createElement("div", null, React.createElement(OtherProfile, null));
