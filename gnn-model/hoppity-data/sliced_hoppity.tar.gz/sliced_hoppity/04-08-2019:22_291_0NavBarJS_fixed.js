// Variables for certain side bar functions.
let togglevar = document.getElementById("sideBartoggleButton");
let closeButton = document.getElementById("closeButton");

// For opening the side navigation bar.
function sideNav() {
    document.getElementById("navBar").style.width = "1000px";
    document.getElementById("sideBartoggleButton").style.left = "30px";
    document.getElementById("menuHeader").innerHTML = "Close";
    document.getElementById("sideBartoggleButton").style.width = "0";
    closeButton.style.left = "-20px"
    togglevar.classList.toggle('active');
}
