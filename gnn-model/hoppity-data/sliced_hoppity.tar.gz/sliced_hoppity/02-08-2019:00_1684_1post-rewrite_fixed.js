// This is either 'rebase' or 'amend'.
if (process.env.HUSKY_GIT_PARAMS !== 'rebase') {
}
