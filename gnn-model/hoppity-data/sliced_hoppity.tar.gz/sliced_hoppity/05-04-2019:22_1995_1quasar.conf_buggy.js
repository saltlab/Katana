// Configuration for your app

module.exports = function(ctx) {
  return {
    // app plugins (/src/boot)
    boot: ["customComponents", "routerAuthentication"],
  };
};
