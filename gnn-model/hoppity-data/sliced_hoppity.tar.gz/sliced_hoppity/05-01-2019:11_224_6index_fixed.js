export default async npmOptions => {
  const [storybookVersion, polymerLoaderVarion] = await getVersions(
  );
  const packageJson = getPackageJson() || {}; // Maybe we are in a bower only project, still we need a package json
  packageJson.dependencies = packageJson.dependencies || {};
  packageJson.devDependencies = packageJson.devDependencies || {};
  packageJson.scripts = packageJson.scripts || {};
  packageJson.scripts.storybook = 'start-storybook -p 6006';
  packageJson.scripts['build-storybook'] = 'build-storybook';
  const devDependencies = [`@storybook/polymer@${storybookVersion}`];
  const babelDependencies = await getBabelDependencies(npmOptions, packageJson);
  installDependencies(npmOptions, [...devDependencies, ...babelDependencies]);
};
