describe('Shopify#resourceFeedback', () => {
  const fixtures = require('./fixtures/resource-feedback');
  const common = require('./common');
  const scope = common.scope;
  it('creates a resource feedback', () => {
    const input = fixtures.req.create;
    const output = fixtures.res.create;
    scope.post('/admin/resource_feedback.json', input).reply(202, output);
  });
});
