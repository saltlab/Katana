const config = {
	key: localStorageKey,
	storage: AsyncStorage,
	blacklist: ['dimmer', 'schedule', 'liveApi', 'navigation', 'modal', 'addDevice'],
	migrate: migrations,
};
