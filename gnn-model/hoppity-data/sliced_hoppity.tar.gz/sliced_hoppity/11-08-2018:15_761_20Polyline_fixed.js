import Shape from './Shape.js'
export default class Polyline extends Shape {
  constructor (node) {
    super(nodeOrNew('polyline', node), node)
  }
}
