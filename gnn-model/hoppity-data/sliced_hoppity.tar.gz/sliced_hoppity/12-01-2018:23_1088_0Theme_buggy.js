const theme = {
  primary: '#5B6DFF',
  secondary: '#9F6EFF',
  primaryDark: '#0042cb',
  primaryLight: '#969bff',
  secondarydDark: '#6b40cb',
  secondaryLight: '#d49eff'
}
