const obj2 = {
  a: {
    b: {
      prop: 'b'
    }
  }
}
const new3 = JSON.parse(JSON.stringify(obj2))
