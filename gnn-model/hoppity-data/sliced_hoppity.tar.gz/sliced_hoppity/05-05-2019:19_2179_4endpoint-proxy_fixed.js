const fastify = require('fastify')({})
fastify.register(require('./../index'), {
})
