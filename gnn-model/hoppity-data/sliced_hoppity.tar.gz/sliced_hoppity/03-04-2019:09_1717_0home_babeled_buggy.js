import React, { Component } from 'react';
class Home extends Component {
  render() {
    return React.createElement("div", {
      className: "kiwi"
    }, React.createElement("h3", null, "Srinivas Challagulla  Unity with Data Science"));
  }
}
