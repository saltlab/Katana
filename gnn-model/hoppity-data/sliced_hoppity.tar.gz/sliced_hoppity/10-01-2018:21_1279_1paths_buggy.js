function update_v_dvdt_optical(vehicle){
    if( (vehicle.id!=1) && (vehicle.isRegularVeh)){

        var laneFraction=vehicle.fractOpticalLCDelay;
    }
}
