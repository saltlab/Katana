
module.exports = {
    helloWorld: function(req , res) {
        res.send("hello 2018222");
    }
}
