'use strict';
function find_child(parent, name, attr) {
}
function orig_save(e, attr, val) {
    if (e.attributes[attr] == undefined) return;
    if (val == undefined) val = e.attributes[attr].value;
}
function g_to_text(e) {
}

function g_to_func(e) {
    var func = g_to_text(e);
    if (func != null)
        func = func.replace(/ .*/, "");
}
function zoom_child(e, x, ratio) {
    if (e.attributes != undefined) {
        if (e.attributes["x"] != undefined) {
            e.attributes["x"].value = (parseFloat(e.attributes["x"].value) - x - 10) * ratio + 10;
            if (e.tagName == "text") e.attributes["x"].value = find_child(e.parentNode, "rect", "x") + 3;
        }
        if (e.attributes["width"] != undefined) {
            e.attributes["width"].value = parseFloat(e.attributes["width"].value) * ratio;
        }
    }
    if (e.childNodes == undefined) return;
    for (let i = 0, c = e.childNodes; i < c.length; i++) {
        zoom_child(c[i], x - 10, ratio);
    }
}

function zoom_parent(e, svg) {
    if (e.attributes) {
        if (e.attributes["x"] != undefined) {
            orig_save(e, "x");
            e.attributes["x"].value = 10;
        }
        if (e.attributes["width"] != undefined) {
            e.attributes["width"].value = parseInt(svg.width.baseVal.value) - (10 * 2);
        }
    }
}
