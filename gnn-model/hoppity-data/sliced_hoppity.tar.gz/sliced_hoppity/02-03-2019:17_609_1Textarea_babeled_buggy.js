import React from 'react';
class Component extends React.Component {
  render() {
    const config = this.props.config || {};
    const message = this.props.info || config.info;
    return React.createElement("div", null, message && React.createElement("div", {
    }, React.createElement("p", null, message)), React.createElement("div", {
    }, React.createElement("textarea", {
      rows: "16",
    })));
  }
}
