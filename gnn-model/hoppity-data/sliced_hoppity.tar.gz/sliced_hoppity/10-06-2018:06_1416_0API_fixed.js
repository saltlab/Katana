import axios from "axios";
export default {
    addItem: function (itemData) {
        return axios.post('http://www.stockandtrack.com/api/post', itemData)
    }
 };
