const { error } = require('dotenv').config();

// add in a check for production
// if (error) {
//   throw error;
// }

const { SPACE_ID, ACCESS_TOKEN } = process.env;

module.exports = {
  siteMetadata: {
    title: 'Site logo',
  },
}
