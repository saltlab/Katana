import $ from 'jquery';
class StickyHeader {
  constructor() {
    this.lazyImages = $(".lazyload");
  }
  }
  export default StickyHeader;
