import React from 'react';
import moment from 'moment';
function ReplyItem({
  reply,
  date,
  user
}) {
  return React.createElement("div", {
    className: "row grey-background"
  }, React.createElement("li", {
    className: "col s2 grey-background"
  }, React.createElement("p", null, React.createElement("img", {
    alt: "image of user",
    className: "circle responsive-img",
    src: user.image,
    style: {
      maxWidth: "50px"
    }
  })), React.createElement("p", {
    className: "comment-height"
  }, user.name)), React.createElement("li", {
    className: "col s8 grey-background"
  }, React.createElement("p", {
    className: "comment-height"
  }, reply.text)), React.createElement("li", {
    className: "col s2 grey-background"
  }, React.createElement("p", {
    className: "comment-height"
  }, moment(date).format("MMMM DD, YYYY"))));
}
