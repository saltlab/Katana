var gulp = require('gulp');
var exit = require('gulp-exit');
var mocha = require('gulp-mocha');
var gutil = require('gulp-util');
function test() {
  var filename = gutil.env.file || '*';
  gulp.src([
      './test/**/test.' + filename + '*'
    ])
    .pipe(mocha({
      reporter: 'spec',
      report: 'lcovonly',
      timeout: 2000
    }))
    .pipe(exit());
}
