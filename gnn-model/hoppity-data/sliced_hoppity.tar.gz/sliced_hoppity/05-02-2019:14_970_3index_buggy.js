module.exports = Object.assign(
  {
    CatalogPage: {
      success_panel: '//*[@id="content"]/div[@class="bootstrap"]/div[contains(@class, "success")]',
    }
  },
);
