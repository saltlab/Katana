export const setCurrentMenuModifier = (state, payload) => {
  state.currentMenuModifiers = payload
}
