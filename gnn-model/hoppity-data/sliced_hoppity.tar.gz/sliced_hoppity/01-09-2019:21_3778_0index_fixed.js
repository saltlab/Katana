function logDriverByHometown(drivers, location) {
   drivers.forEach(driver => {
    if (driver.hometown === location){
      return driver.name
    };
  })
}
