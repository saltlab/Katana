function verificaDati(){
    // Variabili associate ai campi del modulo
    var cf = document.agg.cf.value;
    var nome = document.agg.nome.value;
    var cognome = document.agg.cognome.value;

    //Effettua il controllo sul campo CF
    if ((cf == "") || (cf == "undefined") || (cf.length!=16)) {
        alert("Il campo CF e' obbligatorio e deve contenere 16 CARATTERI.");
        document.agg.cf.select();
        return false;
    }

    //Effettua il controllo sul campo NOME
    else if ((nome == "") || (nome == "undefined")) {
        alert("Il campo Nome e' obbligatorio.");
        document.agg.nome.focus();
        return false;
    }

    //Effettua il controllo sul campo COGNOME
    else if ((cognome == "") || (cognome == "undefined")) {
        alert("Il campo Cognome e' obbligatorio.");
        document.agg.cognome.focus();
        return false;
    }

    //INVIA IL MODULO
    else {
        //document.agg.action = "inserisciComp.php";
        //document.agg.submit();
        return true;
    }
}

function verificaDati_Att(){
    // Variabili associate ai campi del modulo
    var nome = document.att.nome.value;
    var oraInizio= document.att.oraInizio.value;
    var oraFine=document.att.oraFine.value;
    var descr=document.att.descrizione.value;

    //Effettua il controllo sul campo NOME
    if ((nome == "") || (nome == "undefined")) {
        alert("Il campo Nome e' obbligatorio.");
        document.att.nome.focus();
        return false;
    }

    if ((descr == "") || (descr == "undefined")) {
        alert("Il campo descrizione e' obbligatorio.");
        document.att.descrizione.focus();
    }
}
