import React, { Component, Fragment } from "react";
import Typography from "@material-ui/core/Typography";
class Welcome extends Component {
  render() {
    return React.createElement(Fragment, null, React.createElement(Typography, {
      variant: "h5",
    }, "Welcome!"));
  }
}
