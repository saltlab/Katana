var S$ = require('S$');
var testStr = S$.symbol('A', 'H');
if (testStr.lastIndexOf('D') == 3) {
}
