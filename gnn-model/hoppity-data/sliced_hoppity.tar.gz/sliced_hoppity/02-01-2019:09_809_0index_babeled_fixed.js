import * as serviceWorker from './serviceWorker';
serviceWorker.unregister({});
