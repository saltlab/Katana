(function () {
  describe('Articles Route Tests', function () {
    describe('Route Config', function () {
      describe('List Route', function () {
        var liststate;
        beforeEach(inject(function ($state) {
          liststate = $state.get('articles.list');
        }));
        it('Should have templateUrl', function () {
          expect(liststate.templateUrl).toBe('modules/articles/client/views/list-articles.client.view.html');
        });
      });
    });
  });
}());
