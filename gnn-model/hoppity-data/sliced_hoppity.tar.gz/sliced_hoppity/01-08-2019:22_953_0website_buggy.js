const work = require('./work');
const tailwind = require('../tailwind.config');

module.exports = {
  pathPrefix: '/',

  siteTitle: 'Wouter van Marrum',
  siteTitleAlt: 'Wouter',
  siteUrl: 'localhost:3000',
  siteLanguage: 'en',
  // siteLogo: '/logos/logo-1024.png',
  siteDescription: 'Resume and portfolio',

  userTwitter: '@concept_core_nl',

  // Manifest and Progress color
  themeColor: tailwind.colors["grey-light"],
  backgroundColor: '#243e4b',

  // Contact information
  fullName: 'Wouter van Marrum',
  currentExperience: `${work.experiences[0].role} at ${
    work.experiences[0].company
  }`,
};
