 (function() {
    'use strict';

    if (!global.cloudcmd)
        return console.log(
             '# server.js'                                      + '\n'  +
             '# -----------'                                    + '\n'  +
             '# Module is part of Cloud Commander,'             + '\n'  +
             '# easy to use web server.'                        + '\n'  +
             '# http://cloudcmd.io'                             + '\n');

    var main                = global.cloudcmd.main,

        DIR                 = main.DIR,
        LIBDIR              = main.LIBDIR,
        SRVDIR              = main.SRVDIR,

        URL                 = main.url,
        Path                = main.path,
        Querystring         = main.querystring,

        Minify              = main.minify,
        CloudFunc           = main.cloudfunc,
        AppCache            = main.appcache,
        Socket              = main.socket,
        Console             = main.console,
        Terminal            = main.terminal,

        zlib                = main.zlib,
        http                = main.http,
        https               = main.https,
        Util                = main.util,
        express             = main.express,
        expressApp,
        files               = main.files,

        Server, Rest, Route;

    /* базовая инициализация  */
    function init(pAppCachProcessing) {
        var config = main.config;

        /* создаём файл app cache */
        if (config.appcache  && AppCache && config.server )
            Util.exec( pAppCachProcessing );
    }


    /**
     * start server function
     * @param pConfig
     * @param pProcessing {index, appcache, rest}
     */




    function start(options) {
        var redirectServer, port, ip, ssl, sslPort,
            sockets, httpServer, serverLog,
            HTTP       = 'http://',
            HTTPS      = 'https://',
            config         = main.config;

        if (!options)
            options = {};

        Rest    =   options.rest;
        Route   =   options.route;

        init(options.appcache);

        port    =   process.env.PORT            ||  /* c9           */
                    process.env.app_port        ||  /* nodester     */
                    process.env.VCAP_APP_PORT   ||  /* cloudfoundry */
                    config.port,
        ip      =   process.env.IP              ||  /* c9           */
                    config.ip                   ||
                    (main.WIN32 ? '127.0.0.1' : '0.0.0.0'),

        ssl     = options.ssl,
        sslPort = config.sslPort,

        sockets    = function(pServer) {
            var listen, msg,
                status = 'off';

            if (config.socket && Socket) {
                listen = Socket.listen(pServer);

                if (listen) {
                    status = 'on';
                    Console.init();
                    Terminal.init();
                }
            }

            msg     = CloudFunc.formatMsg('sockets', '', status);

            Util.log(msg);
        },

        httpServer = function() {
            expressApp  = express.getApp([
                Rest,
                Route,
                join,
                controller
            ]);

            Server      = http.createServer(expressApp || respond);

            Server.on('error', Util.log.bind(Util));
            Server.listen(port, ip);
            serverLog(HTTP, port);
            sockets(Server);
        },

        serverLog  = function(http, port) {
            Util.log('* Server running at ' + http + ip + ':' + port);
        };
        /* server mode or testing mode */
        if (config.server)
            if (ssl) {
                Util.log('* Redirection http -> https is setted up');

                redirectServer =  http.createServer(function(req, res) {
                    var url,
                        host        = req.headers.host,
                        parsed      = url.parse(host),
                        hostName    = parsed.protocol;
                    url             = HTTPS + hostName + sslPort + req.url;

                    main.redirect({
                        response: res,
                    });
                });

                redirectServer.listen(port, ip);

                Server  =  https.createServer(ssl, respond);
                Server.on('error', function (error) {
                    Util.log(error, '\nCould not use https port: ' + sslPort);
                    redirectServer.close();
                    Util.log('* Redirection http -> https removed');
                    httpServer();
                });

                sockets(Server);

                Server.listen(sslPort, ip);
                serverLog(HTTPS, sslPort);
            }
    }
})();
