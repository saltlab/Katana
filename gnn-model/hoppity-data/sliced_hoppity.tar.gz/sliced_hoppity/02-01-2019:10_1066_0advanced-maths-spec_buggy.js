var chai = require('chai');
var expect = chai.expect;
var AdvancedMaths = require('../../modules/advanced-maths');
describe('AdvancedMaths', function() {
  describe('fibonacci()' , function() {
    it('should return 55 when 10 is entered', function() {
      expect(AdvancedMaths.fibonacci(10)).to.equal(55);
    });
  });
});
