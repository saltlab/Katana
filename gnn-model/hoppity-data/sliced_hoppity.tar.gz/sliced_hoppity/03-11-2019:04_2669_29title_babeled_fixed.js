describe('Component > Modification > Project', () => {
  it('renders correctly', () => {
    const updateModificationFn = jest.fn();
    expect(updateModificationFn).not.toHaveBeenCalled();
  });
});
