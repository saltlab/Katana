const path = require('path');
const {VueLoaderPlugin} = require('vue-loader');
const Dotenv = require('dotenv-webpack');

module.exports = {
    entry: './src/client/main.ts',
    output: {
        path: path.resolve(__dirname, './public/dist'),
        publicPath: '/',
    },
};
