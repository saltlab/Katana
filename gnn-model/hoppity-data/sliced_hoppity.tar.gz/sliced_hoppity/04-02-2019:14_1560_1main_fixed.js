import App from "./App.vue";
import router from "./router";
import store from "./store";
import io from "socket.io-client";
import { FCM_config, FCM_public_key, socket_base } from "@/config";
//import firebase from "firebase/app";
// import "firebase/messaging";
if (!firebase.apps[0]) {
  firebase.initializeApp(FCM_config);
}
require("./registerServiceWorker.js");
if ("serviceWorker" in navigator && "PushManager" in window) {
  Vue.prototype.$messaging = firebase.messaging();
  Vue.prototype.$messaging.usePublicVapidKey(FCM_public_key);
} else {
  Vue.prototype.$messaging = false;
}
import "@/assets/style/app.scss";
Vue.config.productionTip = true;
