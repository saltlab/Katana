import React from 'react';
import EditMovie from './EditMovie';
class MovieCard extends React.Component {
  render() {
    return React.createElement("div", {
    }, React.createElement(Card, null, React.createElement(CardBody, null, React.createElement(CardTitle, null, this.props.movie.title), React.createElement(CardSubtitle, null, this.props.movie.director)), React.createElement(CardImg, {
    }), React.createElement(CardBody, {
    }, React.createElement(CardText, null, this.props.movie.description), React.createElement(CardText, null, React.createElement("span", null, this.props.movie.genre), React.createElement("span", null, this.props.movie.rating)), React.createElement(CardText, null, React.createElement(EditMovie, {
    }), React.createElement("span", {
      className: "btn btn-outline-danger btn-sm"
    }, "Delete")), React.createElement(CardText, null, this.props.movie.updated_at))));
  }
}
