import React from "react";
const Overlay = ({
  overlay,
  showOverlay
}) => {
  if (overlay) {
    return React.createElement("div", {
      className: "overlay"
    }, React.createElement("button", {
      onClick: () => showOverlay(false),
      className: "close",
      href: "#"
    }, "x"));
  }
};
