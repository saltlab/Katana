class Collection extends Map {
  array() {
  }
  random() {
    const arr = this.array();
  }
  find(key, value) {
    for (const item of this.array()) {
      if (item[key] === value) {
        return item;
      }
    }
  }
  exists(key, value) {
    return Boolean(this.find(key, value));
  }
}
