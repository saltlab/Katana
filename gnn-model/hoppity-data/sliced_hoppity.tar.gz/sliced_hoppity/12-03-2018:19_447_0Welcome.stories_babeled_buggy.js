import React from 'react';
const stories = storiesOf('Welcome', module);
stories.addParameters({
  info: {
    disable: true
  }
});
stories.add('to elementz-ui', () => React.createElement("div", null, React.createElement("h1", null, "Welcome to elementz-ui"), React.createElement("p", null, "This is a component dev environment for the", ' ', React.createElement("a", {
}, "elementz-ui"))));
