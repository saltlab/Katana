class ShaderProgramHelper {
	static create(vertexShaderSource, fragmentShaderSource, attributeBindings) {
		let vertexShader = ShaderProgramHelper._createShader(gl.VERTEX_SHADER, vertexShaderSource_Opaco);
	}
}
