import React, { Component } from "react";
class Navigation extends Component {
  render() {
    return React.createElement("div", {
      className: "container main-nav"
    }, React.createElement("div", {
      className: "row"
    }, React.createElement("div", {
      className: "col-md-2 col-sm-2 nav-left"
    }, React.createElement("h2", null, "DE'MOTION")), React.createElement("div", {
      className: "col-md-6 col-sm-6"
    }, React.createElement("div", {
      className: "nc"
    }, React.createElement("div", {
      className: "ncs nav-center"
    }, React.createElement("ul", null, React.createElement(Link, {
      to: "/"
    }, React.createElement("li", null, "Home")), React.createElement(Link, {
      to: "/facedetection"
    }, React.createElement("li", null, "Face Detection")), React.createElement(Link, {
      to: "/color"
    }, React.createElement("li", null, "Color")), React.createElement(Link, {
      to: "/profile"
    }, React.createElement("li", null, "Profile")))))), React.createElement("div", {
      className: "col-md-4 col-sm-4"
    }, React.createElement("div", {
      className: "nc"
    }, React.createElement("div", {
      className: "ncs nav-right"
    }, React.createElement("ul", null, React.createElement(Link, {
      to: "/login"
    }, React.createElement("li", null, "Login")), React.createElement(Link, {
      to: "/logout"
    }, React.createElement("li", null, "Logout"))))))));
  }
}
