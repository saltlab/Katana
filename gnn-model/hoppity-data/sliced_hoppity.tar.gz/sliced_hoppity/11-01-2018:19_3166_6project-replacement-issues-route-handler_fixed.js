const DateSanitizer = require('../transformations/date-sanitizer')
function mexicanLowLevelIssues (req, res, next) {
  const date = new DateSanitizer().createAtTheBeginning(req.params.date)
}
