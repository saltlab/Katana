import _get from 'lodash/get'
export class WithdrawalDetailsRequestRecord extends RequestRecord {
  constructor (record) {
    this.address = _get(record, 'details.createWithdraw.externalDetails.address')
  }
}
