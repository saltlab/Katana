const initState = {
    showFPS: true,
    hideStatusBar: true,
    nextMugShot: 0,
};
