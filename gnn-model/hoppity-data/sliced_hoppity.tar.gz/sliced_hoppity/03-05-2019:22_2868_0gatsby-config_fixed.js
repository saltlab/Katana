module.exports = {
  siteMetadata: {
    name: 'Jamie Davies | Software Engineer',
    description: 'My name is Jamie Davies, I\'m a Software Engineer'
  },
}
