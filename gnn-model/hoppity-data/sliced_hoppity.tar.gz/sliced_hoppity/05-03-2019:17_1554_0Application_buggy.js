Ext.define("NOC.inv.reportifacestatus.Application", {
    items: {
        controls: [
            {
                boxLabel: __("Exclude ports in the status down"),
            },
        ],
    }
});
