import ironStore from "iron-store";

function throwOnNoPassword() {
  throw new Error("next-iron-sesion: Missing parameter `password`");
}
