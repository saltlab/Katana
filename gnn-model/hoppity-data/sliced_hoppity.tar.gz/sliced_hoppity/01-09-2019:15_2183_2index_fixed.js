import VueI18n from 'vue-i18n'
import Cookies from 'js-cookie'
const i18n = new VueI18n({
  locale: Cookies.get('language') || 'zh',
})
