const MoonMVL = require("moon-mvl");
const { Asset } = require("parcel");
class MoonAsset extends Asset {
	async generate() {
		const { js, css } = MoonMVL(this.basename.slice(0, -4), this.contents);
	}
}
