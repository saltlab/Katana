Prism.languages.css.selector = {
	inside: {
		'pseudo-class': {
			inside: {
				'selector': {
					pattern: /(^:(?:has|is|not|where)\()[\s\S]+(?=\)$)/,
				},
			}
		},
	}
};
