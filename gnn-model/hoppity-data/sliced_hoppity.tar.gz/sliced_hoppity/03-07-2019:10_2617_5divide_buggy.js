function divide(a, b) {
}
divide.code = '/';
