var kittens = ["Milo", "Otis", "Garfield"] //define your array here
function destructivelyRemoveFirstKitten(name) {
  kittens.slice(0)
}
