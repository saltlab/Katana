import React from "react";
const Home = () => React.createElement("header", null, React.createElement("div", {
}, React.createElement("div", {
}, React.createElement("div", null, React.createElement("img", {
  alt: "upload"
}), React.createElement("p", null, "Upload an image to detect any disease"), React.createElement("button", null, "Upload Image")))));
