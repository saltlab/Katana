export const Header = {
  containerStyle: {
    marginTop: Platform.OS === 'ios' ? 70 : 0,
  },
};
