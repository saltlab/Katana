import React, { Component } from 'react';
import Timeline from './Timeline';
import NavBar from './NavBar';
class App extends Component {
  render() {
    return React.createElement("div", {
    }, React.createElement(NavBar, null), React.createElement(Timeline, {
      name: "Simn"
    }));
  }
}
