const router = require('express').Router();
const restricted = require('../../auth/middleware/restricted-middleware.js');
const Donations = require('./donationsModel.js');
router.post('/', restricted, (req, res) => {
	Donations.add(req.body)
		.then(newDonations => {
			res.json({ newDonations });
		})
});
