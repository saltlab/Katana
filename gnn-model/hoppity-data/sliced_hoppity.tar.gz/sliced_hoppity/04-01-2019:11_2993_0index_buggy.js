const Hapi = require('hapi')
const server=Hapi.server({
    port:80
});
