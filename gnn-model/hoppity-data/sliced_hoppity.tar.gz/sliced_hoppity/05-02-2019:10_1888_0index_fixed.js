function takeANumber(katzDeliLine, name) {
  return (`Welcome, ${name}. You are number ${katzDeliLine.length} in line.`)
}
