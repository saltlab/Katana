function dwarfRollCall(dwarves) {

}
function findTheCheese (foods) {
  for(var i=0; i<foods.length; i++) {
    if(foods.indexOf("cheddar", "gouda", "camembert")){} else {return `no cheese!`}
   }
}
