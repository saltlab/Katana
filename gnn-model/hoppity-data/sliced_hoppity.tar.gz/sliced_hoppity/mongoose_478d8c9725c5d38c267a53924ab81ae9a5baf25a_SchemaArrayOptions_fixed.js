const SchemaTypeOptions = require('./SchemaTypeOptions');
class SchemaArrayOptions extends SchemaTypeOptions {}

const opts = require('./propertyOptions');

Object.defineProperty(SchemaArrayOptions.prototype, 'of', opts);
