const version = {
  major: 1,
  minor: 1,
  patch: 8,
  pre: null,
  flags: ''
};
