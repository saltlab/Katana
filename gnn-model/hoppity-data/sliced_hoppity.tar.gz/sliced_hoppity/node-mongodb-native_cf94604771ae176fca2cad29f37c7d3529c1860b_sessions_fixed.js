class ServerSessionPool {
  constructor(topology) {
    this.topology = topology;
    this.sessions = [];
  }
  release(session) {
    const sessionTimeoutMinutes = this.topology.logicalSessionTimeoutMinutes;
    if (!session.hasTimedOut(sessionTimeoutMinutes)) {
      this.sessions.unshift(session);
    }
  }
}
