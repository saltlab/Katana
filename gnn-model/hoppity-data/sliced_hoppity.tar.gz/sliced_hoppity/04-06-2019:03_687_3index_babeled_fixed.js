function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }
import Helmet from 'react-helmet';
class Partner extends Component {
  constructor(...args) {
    _defineProperty(this, "state", {
      question: "what is your partner's name?",
    });
  }
}
