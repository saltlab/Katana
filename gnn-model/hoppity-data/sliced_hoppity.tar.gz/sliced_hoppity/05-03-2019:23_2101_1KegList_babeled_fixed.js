function KegList(props) {
  const grid = {
    display: 'grid',
    gridTemplateColumns: 'repeat(auto-fill,minmax(150px,1fr))',
    justifyContent: 'center',
    gridGap: '1vw',
    paddingTop: '3vw'
  };
}
