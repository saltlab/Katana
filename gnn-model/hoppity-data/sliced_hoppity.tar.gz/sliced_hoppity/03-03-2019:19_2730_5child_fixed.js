const express = require('express');
const passport = require('passport');
const router = express.Router();
router.get('/childUser/:id', passport.authenticate(['parent-rule','admin-rule'], { session: false }),(req,res)=>{
    const params = {_id:req.params.id};
});
