const express = require("express")
const graphqlHTTP = require('express-graphql');
const cors = require('cors')

const log = require('./log.js')

const teal = require("./graphql.js")

const app = express();
app.use(cors())

app.use('/graphql', graphqlHTTP({
  schema: teal.schema,
  rootValue: teal.root,
  graphiql: true,
}));
