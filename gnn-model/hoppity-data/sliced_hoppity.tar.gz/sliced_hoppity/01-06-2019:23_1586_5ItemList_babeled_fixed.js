import React from 'react';
import Item from './Item';
export const ItemList = props => {
  return React.createElement("ul", {
  }, props.items && props.items.sort(sortByCategory).map(item => {
    return React.createElement(Item, {
      itemId: item.id,
    });
  }));
};
