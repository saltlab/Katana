export const setCurrentThemeAction = value => ({
    value,
});
const setCurrentTheme = (state, action) => {
    const { value } = action;
    console.info('setting theme to', themes[value].title);
};
