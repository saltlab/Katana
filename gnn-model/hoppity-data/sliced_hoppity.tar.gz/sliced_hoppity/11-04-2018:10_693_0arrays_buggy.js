function destructivelyRemoveElementFromBeginningOfArray(array){
  const earray = array
  earray.sfhit()
}
