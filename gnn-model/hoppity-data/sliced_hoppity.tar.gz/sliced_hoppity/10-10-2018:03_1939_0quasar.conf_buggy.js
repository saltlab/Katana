// Configuration for your app

module.exports = ctx => {
  return {
    plugins: ['i18n', 'axios', 'vuelidate', 'clipboards', 'filters', 'tools', 'channel'],
  }
}
