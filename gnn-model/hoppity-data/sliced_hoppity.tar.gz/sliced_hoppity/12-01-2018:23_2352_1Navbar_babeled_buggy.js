import React from 'react';
import AnchorLink from 'react-anchor-link-smooth-scroll';
const Navbar = props => {
  return React.createElement("nav", {
    className: "navbar navbar-default navbar-static-top",
    role: "navigation"
  }, React.createElement("div", {
    className: "container"
  }, React.createElement("div", {
    className: "navbar-header"
  }, React.createElement("button", {
    type: "button",
    className: "navbar-toggle collapsed",
    "data-toggle": "collapse",
    "data-target": ".navbar-collapse"
  }, React.createElement("span", {
    className: "sr-only"
  }, "Toggle navigation"), React.createElement("span", {
    className: "icon-bar"
  }), React.createElement("span", {
    className: "icon-bar"
  }), React.createElement("span", {
    className: "icon-bar"
  }))), React.createElement("div", {
    className: "navbar-collapse collapse"
  }, React.createElement("ul", {
    className: "nav navbar-nav",
    id: "main-menu"
  }, React.createElement("li", null, React.createElement(AnchorLink, {
    href: "#page-home"
  }, "Home")), React.createElement("li", null, React.createElement(AnchorLink, {
    href: "#page-skills"
  }, "Skills")), React.createElement("li", null, React.createElement(AnchorLink, {
    href: "#page-resume"
  }, "Resume")), React.createElement("li", null, React.createElement(AnchorLink, {
    href: "#page-profile"
  }, "Me")), React.createElement("li", null, React.createElement(AnchorLink, {
    href: "#page-contact"
  }, "Contact"))))));
};
