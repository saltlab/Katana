const mongoose = require("mongoose");
const Survey = mongoose.model("surveys");
