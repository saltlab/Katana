const router = require('express').Router()
router.use('/dev', require('./webdev'))
