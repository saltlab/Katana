const path = require("path");
const process = require("process");
const convert = require("koa-connect");
const proxy = require("http-proxy-middleware");

module.exports = {
    entry: "./src/index.tsx",

    mode: process.env.WEBPACK_SERVE ? "development" : "production",

    output: {
        filename: "./bundle.js"
    },
};
