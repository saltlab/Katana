module.exports = {
  apps: [
    {
      name: 'gongmo',
      script: 'src/app.js',
    }
  ]
}
