import React from 'react';
class LeftDirectory extends React.Component {
  render() {
    return React.createElement("div", {
    }, React.createElement("div", {
    }), React.createElement("div", {
    }, this.renderMainIndex()));
  }
}
