import employeeFormReducer from './EmployeeFormReducer';
export default combineReducers({
  employeeFrom: employeeFormReducer
});
