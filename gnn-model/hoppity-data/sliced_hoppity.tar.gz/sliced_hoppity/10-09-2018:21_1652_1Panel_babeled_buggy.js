export default class WizardPanel extends Component {
  constructor(props) {
    super(props);
    this.state = {
      panel
    };
  }
  get classes() {
  }
  render() {
    return React.createElement("div", {
      className: this.classes
    }, React.createElement("h3", null, this.state.panel.title), this.state.panel.content || '');
  }
}
