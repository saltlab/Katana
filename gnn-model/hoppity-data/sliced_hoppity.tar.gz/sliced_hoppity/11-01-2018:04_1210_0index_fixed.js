function happyHolidaysTo(name) {
  return `Happy holidays, ${name}!`
}
