    _       = require('lodash'),
    validation  = require('../data/validation'),
    utils;
utils = {
    validateOptions: function validateOptions(options) {
        var globalValidations = {
                id: {matches: /^\d+|me$/},
                uuid: {isUUID: true},
                page: {matches: /^\d+$/},
                limit: {matches: /^\d+|all$/},
                fields: {matches: /^[a-z0-9_,]+$/},
                name: {}
            },
            // these values are sanitised/validated separately
            noValidation = ['data', 'context', 'include'],
            errors = [];
        _.each(options, function (value, key) {
            // data is validated elsewhere
            if (noValidation.indexOf(key) === -1) {
                if (globalValidations[key]) {
                    errors = errors.concat(validation.validate(value, key, globalValidations[key]));
                } else {
                    errors = errors.concat(validation.validate(value, key, {matches: /^[a-z0-9\-]+$/}));
                }
            }
        });
    },
};
