var cart = [];

function setCart(c) {
  cart = c;
}
function viewCart() {
  if(cart.length===0){
    return `Your shopping cart is empty.`
  }

  var itemsWithPrice = []
  for(let i=0; i< cart.length; i++){
    var keys = Object.keys(cart[i])[0]
    itemsWithPrice.push(keys + ' at $' + cart[i][keys])
  }
}
