Package.on_use(function (api) {
  api.use('underscore', 'server');
});
