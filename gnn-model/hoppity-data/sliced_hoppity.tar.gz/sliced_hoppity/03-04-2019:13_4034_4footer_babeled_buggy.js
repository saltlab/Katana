import React from "react";
const Footer = props => {
  return React.createElement("div", {
    className: "footer "
  }, React.createElement("p", null, React.createElement("span", null, "wrogoz@gmail.com"), " 2019"));
};
