const getLinesFromHead = function(contents, numOfLines = 10){
}
const getCharsFromHead = function(contents, numOfChar){
}
const readFile = function(readFileSync, path, encoding){
}
const head = function(files, option, value, fileNames){
  let opration = getLinesFromHead;
  let count = 0;
  if(option == '-c'){
    opration = getCharsFromHead;
  }
  return files.map(file => {
    return `==> ${fileNames[count++]} <==\n${opration(file, value)}`;
  });
}
