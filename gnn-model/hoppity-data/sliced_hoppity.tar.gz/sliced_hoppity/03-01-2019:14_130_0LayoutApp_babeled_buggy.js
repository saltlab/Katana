function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }
class LayoutApp extends Component {
  constructor(...args) {
    _defineProperty(this, "state", {
      active: 'fieldArrayDynamic'
    });
  }
}
