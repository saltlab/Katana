const { BOOL } = require('../../constants')
async function decode (genericDecoder, buf) {
}
