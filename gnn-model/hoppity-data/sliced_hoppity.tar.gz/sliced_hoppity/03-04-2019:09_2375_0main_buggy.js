$(document).ready(function() {
  $('.viewlarge').magnificPopup({
  });
});
