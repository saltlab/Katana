class LoginView extends Component {
  componentDidMount() {
    const query = this.props.history.location.pathname;
    if (query.length > 30) {
    }
  }
}
