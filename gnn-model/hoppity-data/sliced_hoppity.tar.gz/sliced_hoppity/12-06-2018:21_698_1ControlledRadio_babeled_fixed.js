import React from 'react';
class ControlledRadio extends React.Component {
  render() {
    return React.createElement(React.Fragment, null, React.createElement(Radio, {
    }), ' ', React.createElement(Radio, {
      name: "pf-version2",
    }));
  }
}
