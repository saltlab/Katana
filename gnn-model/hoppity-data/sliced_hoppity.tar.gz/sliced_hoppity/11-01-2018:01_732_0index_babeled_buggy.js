import React, { Component } from 'react';
class Account extends Component {
  constructor(props) {
    this.state = {
      balance: 0
    };
  }
  render() {
    return React.createElement("div", {
      className: "account"
    }, React.createElement("h2", null, this.props.name), React.createElement("div", {
      className: "balance"
    }, "$", this.state.balace), React.createElement("input", {
      type: "text",
      placeholder: "enter an amount",
      ref: input => this.inputBox = input
    }), React.createElement("input", {
      type: "button",
      value: "Deposit",
      onClick: this.handleDepositClick
    }), React.createElement("input", {
      type: "button",
      value: "Withdraw",
      onClick: this.handleWithdrawClick
    }));
  }
}
