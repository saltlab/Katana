export default {
    workbox: {
        dev: true, //開発環境でもPWAできるように
    },
}
