import React from 'react';
class DMWindow extends React.Component {
  createFileBar() {
    let fileBar = [{
    }, {
      buttons: [{
        hotkey: 'CTRL+F',
      }]
    }];
  }
}
