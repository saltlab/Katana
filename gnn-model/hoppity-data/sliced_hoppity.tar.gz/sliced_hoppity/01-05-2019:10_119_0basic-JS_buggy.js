//
// ========================================
//      BASIC SCRIPT FOR INDEX.HTML
// ========================================
//

$(document).ready(function() {
  // ======================================================
  //      short animations for specific elements
  // ======================================================

  $("#linkedIn").addClass("animated rollIn");
  $("#twitter").addClass("animated zoomInDown");
  $("#flickr").addClass("animated fadeInUp");
  $("#pinterest").addClass("animated wobble");


  // ======================================================
  // when something is clicked but the content is not ready
  // ======================================================
  $('.sth').on('click', function() {
    swal({
      type: 'error',
      title: 'Sorry',
    });
  });
});
