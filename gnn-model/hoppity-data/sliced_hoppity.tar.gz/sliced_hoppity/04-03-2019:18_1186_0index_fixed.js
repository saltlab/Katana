function dwarfRollCall(dwarves) {
  for (var i = 0; i < dwarves.length; i++) {
  }
}
function longPlaneteerCalls(words) {
  for (var i = 0; i < words.length; i++) {
  }
}
