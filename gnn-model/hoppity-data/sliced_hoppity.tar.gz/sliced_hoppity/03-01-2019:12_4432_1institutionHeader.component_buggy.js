(function() {
     var app = angular.module('app');
     app.component("institutionHeader", {
        controller: ['$state', 'STATES', function($state, STATES){
            const instHeaderCtrl = this;
            instHeaderCtrl.showButtonMore = function showButtonMore(){
            };
            instHeaderCtrl.isTimeline = function isTimeline(){
            };
            instHeaderCtrl.isRegistrationData = function isRegistrationData(){
            };
            instHeaderCtrl.isDescription = function isDescription(){
            };
            instHeaderCtrl.getTitle = function getTitle(){
                const instName = instHeaderCtrl.institution ? instHeaderCtrl.institution.name : "";
                const limitedInstName = Utils.limitString(instName, 110);
                switch($state.current.name) {
                    case STATES.INST_TIMELINE:
                    case STATES.MANAGE_INST_EDIT: return limitedInstName;
                };
            };
        }],
    });
})();
