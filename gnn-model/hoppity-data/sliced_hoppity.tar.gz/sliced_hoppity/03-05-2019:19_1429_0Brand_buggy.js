define( function( require ) {
  return {
    name: 'PhET<sup>\u00ae</sup> Interactive Simulations', // no i18n
  };
} );
