  export default {
    methods: {
        findTeam() {
            var payload = {
                teamId: parseInt(this.teamID),
                info: 'team'
            };
        }
    }
  }
