const express = require("express");
const PORT = 3000;
require ('custom-env').env('pmm');
var partyResource = require("./resource/partyResource"),
    travelResource = require("./resource/travelResource"),
    connection = require("./model/connection");
var http = require("http");
const app = express();

const swaggerUi = require('swagger-ui-express');
const YAML = require('yamljs');
const swaggerDocument = YAML.load('./swagger.yaml');

app.use('/api-docs', swaggerUi.serve, swaggerUi.setup(swaggerDocument));
app.get("/home", (req,res) => {
});

// Routing to other responsable to handle request
app.use("", partyResource);
app.use(express.static("public"));
var server = app.listen(process.env.PORT || PORT, ()=> {
    console.log("Listen at port : " + process.env.PORT);
})
io = require('socket.io').listen(server);
io.on('connection', (socket) => {
    socket.on("ROL", (rol) => {
    });
});
