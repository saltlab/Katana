function shout(string) {
  return string.toUppercase()
}
