var express = require('express');
var sportsController = require('./sportsController');
var sportsRouting = express.Router();
sportsRouting.route('/findsportsname').post(sportsController.findsportname);
