import axios from "axios"
export default{
        logoutClick(){
            return axios.post('http://localhost/logout')
        }
}
