var react_native_1 = require("react-native");
var styles = react_native_1.StyleSheet.create({
    line: {
        backgroundColor: "#EC8765"
    }
});
