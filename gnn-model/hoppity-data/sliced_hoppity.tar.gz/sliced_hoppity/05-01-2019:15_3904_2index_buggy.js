Page({
  getList() {
    let infoOpt = {
      url: 'quality/notice',
      type: 'GET',
      data: {
        state:1,
        pageNo:1,
        pageSize:10
      }
    }
  },
})
