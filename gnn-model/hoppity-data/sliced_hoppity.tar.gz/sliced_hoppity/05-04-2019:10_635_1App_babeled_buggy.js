import React from 'react';
export default class App extends React.Component {
  constructor(props) {
    this.state = {
      tab: 'admin'
    };
  }
}
