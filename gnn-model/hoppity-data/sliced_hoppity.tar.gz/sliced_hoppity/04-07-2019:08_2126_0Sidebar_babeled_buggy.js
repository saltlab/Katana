import React, { Component } from 'react';
class Sidebar extends Component {
  render() {
    return React.createElement("div", {
      className: "sidenav"
    }, React.createElement("b", null, React.createElement(Icon, {
      name: "user circle",
      size: "large"
    }), " Username"), React.createElement("c", null), React.createElement("c", null), React.createElement("c", null, React.createElement(Icon, {
      name: "mix"
    }), " All mail"), React.createElement("c", null, React.createElement(Icon, {
      name: "mail outline"
    }), " Unread"), React.createElement("c", null, React.createElement(Icon, {
      name: "star half full"
    }), " Starred"));
  }
}
