import React from 'react';
import Layout from '../components/layout';
const IndexPage = () => React.createElement(Layout, null, React.createElement("p", null, "Welcome to your new Gatsby site."));
