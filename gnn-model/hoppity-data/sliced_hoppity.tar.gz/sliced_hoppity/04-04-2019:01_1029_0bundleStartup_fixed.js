export function execute(done, config) {
    const Extensions = require('@jenkins-cd/js-extensions');
    Extensions.init({
        classMetadataProvider: (type, cb) => {
            const fetchOptions = {
                method: 'GET',
                headers: {
                    'Content-Type': 'application/json',
                },
            };
        },
    });
}
