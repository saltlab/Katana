require('dotenv').config()
const resolve = require('path').resolve

module.exports = {
  /*
  ** Headers of the page
  */


  head: {
    title: 'endpass Decentralized Cloud Wallet',
    titleTemplate: '%s | endpass',
    meta: [
      { charset: 'utf-8' },
      { name: 'viewport', content: 'width=device-width, initial-scale=1' },
      { hid: 'description', name: 'description', content: 'Endpass is a decentralized identity platform.' },
			{ name: 'apple-mobile-web-app-title', content: 'Endpass' },
			{ name: 'application-name', content: 'Endpass' },
			{ name: 'msapplication-TileColor', content: '#da532c' },
			{ name: 'theme-color', content: '#ffffff' }
    ],
    link: [
    	{ rel: 'stylesheet', href: 'https://cdnjs.cloudflare.com/ajax/libs/bulma/0.6.2/css/bulma.min.css' },
    ]
  },
}
