import React from 'react';
const Profile = ({
  classes
}) => {
  return React.createElement("div", null, React.createElement("p", null, "just add your profile cards here ", React.createElement("code", null, "/profile/:userId"), "."));
};
