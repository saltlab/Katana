import * as React from 'react';
export default (() => {
  return React.createElement(Footer, null, React.createElement(FooterGrid, null, React.createElement(Masthead, null, React.createElement(Link, {
  }, "Mac")), React.createElement(Support, null, React.createElement("span", null, "Support"), React.createElement(Link, {
    to: `/spectrum`
  }, "Email support")), React.createElement(Safety, null, React.createElement("span", null, "Safety"), React.createElement("a", {
  }, "Terms of Service"))));
});
