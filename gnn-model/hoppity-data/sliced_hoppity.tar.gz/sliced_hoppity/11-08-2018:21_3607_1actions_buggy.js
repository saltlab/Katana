import api from '../../../utils/api';
const loginAction = (data, successCallback) => (dispatch) => {
  api
    .post('users/login/', data)
};
