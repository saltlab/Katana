'use strict';
var express = require("express");
var alexaApp = require("./handlers");

var app = express();
const PORT = process.env.PORT || 5000;
