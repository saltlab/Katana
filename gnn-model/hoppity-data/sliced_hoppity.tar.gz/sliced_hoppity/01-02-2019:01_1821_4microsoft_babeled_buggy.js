import React from 'react';
import Img from 'gatsby-image';
import Layout from '../components/layout';
const microsoft = props => React.createElement(Layout, null, React.createElement("div", {
  style: {
    display: 'flex',
    justifyContent: 'center'
  }
}, React.createElement("div", {
  className: "photo-stack"
}, React.createElement("h1", null, "Microsoft"), React.createElement(Img, {
  fluid: props.data.image1.childImageSharp.fluid
}), React.createElement(Img, {
  fluid: props.data.image2.childImageSharp.fluid
}), React.createElement(Img, {
  fluid: props.data.image3.childImageSharp.fluid
}), React.createElement(Img, {
  fluid: props.data.image4.childImageSharp.fluid
}))));
