export default function({ $axios, store }) {
  if (!store.state.sessionToken) {
  }
}
