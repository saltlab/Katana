import React from 'react';
import Header from '../Header';
describe("Header", function () {
  let mountedHeader;
  beforeEach(() => {
    mountedHeader = shallow(React.createElement(Header, null));
  });
  it('renders a logo', () => {
    const logoImg = mountedHeader.find('img[src="images/coffee_shop.png"]');
  });
});
