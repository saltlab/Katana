var kittens = ["Milo", "Otis", "Garfield"] //define your array here
var moreKittens = ["Broom"]
var evenMoreKittens = ["Arnold"]

function destructivelyAppendKitten(array, name){
  return kittens.push("Ralph");
}
function appendKitten(array, name){
  kittens.concat(moreKittens);
}
