const GAME_WIDTH = 640;
const GAME_HEIGHT = 640;
let flash; // Flash layer.
function setup() {
    flash = new Flash(GAME_WIDTH, GAME_HEIGHT);
}
function draw() {
    flash.display(0, 0);
}
