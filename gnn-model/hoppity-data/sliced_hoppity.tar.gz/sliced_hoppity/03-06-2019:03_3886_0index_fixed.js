function takeANumber(line, name) {
  return (`Welcome, ${name}. You are number ${line.length} in line.`);
}
function nowServing(katzDeliLine) {
  if (katzDeliLine.length > 0) {
  var person = katzDeliLine.shift();
}
}
