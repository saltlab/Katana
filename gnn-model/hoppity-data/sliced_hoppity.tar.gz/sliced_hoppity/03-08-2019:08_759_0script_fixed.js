const fullPage = new fullpage('#fullpage', {
    sectionsColor: ['#ffffff', '#1BBC9B', '#7E8F7C','#C63D0F', ''],
});
