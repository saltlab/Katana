import Component from 'component';
import template from 'template';
const { div, h2 } = template;
export default class ListCreatePage extends Component {
	render() {
		const formWrapper = div({
			children: [
				h2({ text: "Create List", class: "margin-bottom-small font-size-large font-weight-medium padding-left-medium" }),
			]
		})
	}
}
