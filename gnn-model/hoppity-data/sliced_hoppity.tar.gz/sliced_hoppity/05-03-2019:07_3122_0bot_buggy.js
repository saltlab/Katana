const { ActivityHandler } = require('botbuilder');
class MyBot extends ActivityHandler {
    constructor() {
        this.onMessage(async (context, next) => {

            const commands = [{ 'name' : '1', 'value' : 'antri', 'childs' : [{
                'name' : 'server',
                'value' : '33'
            },{
                'name' : 'server',
                'value' : '64'
            }] }, { 'name' : '1', 'value' : 'done', 'childs' : [{
                'name' : 'server',
                'value' : '33'
            },{
                'name' : 'server',
                'value' : '64'
            }] }];
            var text_split = context.activity.text.split(" ");
            var command = "";
            commands.forEach( x => {
                var i = 0;
                text_split.forEach(y=>{
                    if(i==0){
                        if(x.value.indexOf(y)){
                            command = x.value;
                            if(x.childs && x.childs.length){
                                if(text_split[1]){
                                    var text_split_server = text_split[1].split(",");
                                    if(text_split_server.length){
                                    }
                                    text_split_server.forEach(z=>{
                                    });
                                }
                            }
                        }
                    }
                    i++;
                });
            });
            await context.sendActivity('User ' + context.activity.from.name + " requesting to "+command + additional);
        });
    }
}
