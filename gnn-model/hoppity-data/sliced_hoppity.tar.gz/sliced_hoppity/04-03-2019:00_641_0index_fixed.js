const express = require('express');
const zoosRouter = require('./zoos/zoos-router.js');
const server = express();
server.use('/api/zoos', zoosRouter);
