//Creates an interface to access extra features from a graph (like play, stop, live, etc)
function Editor( container_id, options )
{
	var html = "<div class='header'><div class='tools tools-left'></div><div class='tools tools-right'></div></div>";
	html += "<div class='content'><div class='editor-area'><canvas class='graphcanvas' width='1000' height='500' tabindex=10></canvas></div></div>";
	html += "<div class='footer'><div class='tools tools-left'></div><div class='tools tools-right'></div></div>";

	var root = document.createElement("div");
	this.root = root;
	root.className = "litegraph-editor";
	root.innerHTML = html;
	this.tools = root.querySelector(".tools");
	var canvas = root.querySelector(".graphcanvas");
	//create graph
	var graph = this.graph = new LGraph();
	var graphcanvas = this.graphcanvas = new LGraphCanvas(canvas,graph);
	graphcanvas.background_image = "imgs/grid.png";
	graph.onAfterExecute = function() { graphcanvas.draw(true) };

	//add stuff
	//this.addToolsButton("loadsession_button","Load","imgs/icon-load.png", this.onLoadButton.bind(this), ".tools-left" );
	//this.addToolsButton("savesession_button","Save","imgs/icon-save.png", this.onSaveButton.bind(this), ".tools-left" );
	this.addLoadCounter();
	this.addToolsButton("maximize_button","","imgs/icon-maximize.png", this.onFullscreenButton.bind(this), ".tools-right" );
	this.addMiniWindow(300,200);
	//append to DOM

	graphcanvas.resize();
}
Editor.prototype.addLoadCounter = function()
{
	var meter = document.createElement("div");
	meter.className = 'headerpanel loadmeter toolbar-widget';

	var html = "<div class='cpuload'><strong>CPU</strong> <div class='bgload'><div class='fgload'></div></div></div>";
	html += "<div class='gpuload'><strong>GFX</strong> <div class='bgload'><div class='fgload'></div></div></div>";

	meter.innerHTML = html;
	this.root.querySelector(".header .tools-left").appendChild(meter);
	var self = this;

	setInterval(function() {
		meter.querySelector(".cpuload .fgload").style.width = ((2*self.graph.execution_time) * 90) + "px";
	},200);
}
