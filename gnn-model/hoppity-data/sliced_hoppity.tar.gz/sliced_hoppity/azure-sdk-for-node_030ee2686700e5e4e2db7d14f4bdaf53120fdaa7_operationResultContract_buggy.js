class OperationResultContract {
  mapper() {
    return {
      type: {
        modelProperties: {
          error: {
            type: {
              className: 'ErrorResponse'
            }
          },
        }
      }
    };
  }
}
