function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }
import React from 'react';
export default class AuthNavigator extends React.Component {
  constructor(props) {
    _defineProperty(this, "_bootstrapAsync", async () => {
      const userToken = await AsyncStorage.getItem('userToken'); // This will switch to the App screen or Auth screen and this loading
      this.props.navigation.navigate(userToken ? 'App' : 'SignIn');
    });
  } // Fetch the token from storage then navigate to our appropriate place
}
