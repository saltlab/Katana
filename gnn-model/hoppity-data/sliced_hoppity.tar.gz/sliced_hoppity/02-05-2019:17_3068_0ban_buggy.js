const Discord = require("discord.js");

module.exports.run = async (bot, msg, args) => {
	let bUser = msg.guild.member(msg.mentions.users.first() || msg.guild.members.get(args[0]));
	if (!bUser) return msg.channel.send("Please Specify Who you Want To Ban");
	let breason = args.join(" ").slice(22);
	if (!breason) return msg.channel.send(`Please Specify Why you Want To Ban ${bUser}`);
	if(!msg.member.hasPermission("BAN_MEMBERS")) return msg.channel.send("You Cannot Ban People!")
	if (message.author.id === bUser.id) return;
}
