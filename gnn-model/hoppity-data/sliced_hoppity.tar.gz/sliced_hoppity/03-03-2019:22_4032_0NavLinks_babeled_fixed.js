import React from 'react';
const NavLinks = () => {
  return React.createElement("ul", {
    className: "navbar-nav mr-auto"
  }, React.createElement("li", {
    className: "nav-item active"
  }, React.createElement(NavLink, {
    className: "nav-link",
    to: "/"
  }, "Product")), React.createElement("li", {
    className: "nav-item active"
  }, React.createElement(NavLink, {
    className: "nav-link",
    to: "/"
  }, "Bundles")), React.createElement("li", {
    className: "nav-item active"
  }, React.createElement(NavLink, {
    className: "nav-link",
    to: "/about"
  }, "About Us")), React.createElement("li", {
    className: "nav-item active"
  }, React.createElement(NavLink, {
    className: "nav-link",
    to: "/"
  }, "Cart")));
};
