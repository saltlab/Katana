const config = {
  API_ORIGIN: 'https://staging.ratesrebates.services.govt.nz',
  OPENFISCA_ORIGIN: 'https://openfisca.ratesrebates.services.govt.nz/calculate',
  SHOW_HOLDING_PATH: true
};
