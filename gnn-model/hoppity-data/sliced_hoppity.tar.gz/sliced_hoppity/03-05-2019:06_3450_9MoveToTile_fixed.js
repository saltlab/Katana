import GetValue from '../../../utils/object/GetValue.js';
var MoveToTile = function (tileX, tileY, direction) {
    var miniBoard = this.miniBoard;
    var mainBoard = miniBoard.mainBoard;
    if ((tileX != null) && (typeof (tileX) !== 'number')) {
        var config = tileX;
        tileX = GetValue(config, 'x', undefined);
        tileY = GetValue(config, 'y', undefined);
        direction = GetValue(config, 'direction', undefined);
    }
    myTileXY.x = miniBoard.tileX;
    myTileXY.y = miniBoard.tileY;
    if ((direction !== undefined) &&
        (tileX == null) || (tileY == null)) {
        // Get neighbor tile position if direction is not undefined
        var out = mainBoard.getNeighborTileXY(myTileXY, direction, true);
    }
}
