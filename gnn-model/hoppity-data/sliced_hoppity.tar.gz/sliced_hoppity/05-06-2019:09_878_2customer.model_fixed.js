var mongoose=require("mongoose");
var customerSchema=mongoose.Schema(
    {
        name:{
            type:String,
        },
        email:{
        },
        phone:{
            type:String
        },
    }
);
