exports.test = function(req, res){
    res.send('worked');
};
