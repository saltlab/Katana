// declare your functions here...
function paragraphSelector() {
}
function lastImageSelector() {
  return $('img:last');
}
function ninjaBabySelector() {
  return $('baby-ninja');
}
