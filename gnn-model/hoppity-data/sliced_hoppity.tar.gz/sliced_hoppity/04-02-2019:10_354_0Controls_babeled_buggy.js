const Controls = props => {
  const context = useContext(Context);
  const validateSelectedFile = file => {
    return context.updateGridPad(file);
  };
};
