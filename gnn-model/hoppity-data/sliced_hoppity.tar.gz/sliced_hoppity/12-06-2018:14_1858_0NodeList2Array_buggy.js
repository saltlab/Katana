{
    while(--this.length > 0)
        tempArray[this.length] = this[this.length];
};
