var Sequelize = require("sequelize");
var connection = new Sequelize('bomj-trip', 'root', '914191514q', {
	host: 'localhost',
	dialect: "mysql",
	define: {
        timestamps: false
    }
});
