Package.onUse( function(api) {
  api.use(['coffeescript@1.0.9||2.0.0', 'underscore']);
});
