
function exactMatch(dri, revObj) {
  return dri.filter(el => {
    return el[Object.keys(revObj)] === revObj[Object.keys(revObj)]
  })
}
