var kittens = ["Milo", "Otis", "Garfield"] //define your array here
function removeFirstKitten(name) {
  return kittens.slice(0)
}
