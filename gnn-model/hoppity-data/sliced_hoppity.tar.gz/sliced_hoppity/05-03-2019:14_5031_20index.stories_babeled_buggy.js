import React from 'react';
import { storiesOf } from '@storybook/react';
import { number, boolean } from '@storybook/addon-knobs';
import { withInfo } from '@storybook/addon-info';
import { PlayIcon } from '../..';
const iconsStories = storiesOf('PlayIcon', module);
