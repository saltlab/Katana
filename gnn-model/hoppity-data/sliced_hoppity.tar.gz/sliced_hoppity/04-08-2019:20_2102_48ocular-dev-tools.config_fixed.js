const {resolve} = require('path');

module.exports = {
  lint: {
    paths: ['modules', 'dev-modules', 'test', 'examples'],
  },
};
