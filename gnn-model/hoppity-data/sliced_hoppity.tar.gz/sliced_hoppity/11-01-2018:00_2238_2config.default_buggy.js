'use strict';

const path = require('path');

module.exports = appInfo => {
  const config = (exports = {});

  // use for cookie sign key, should change to your own and keep security
  config.keys = appInfo.name + '_1531883447101_6558';
  config.adminPassword = 'admin';

  // add your config here
  config.middleware = ['checktoken', 'checkuser', 'checkauth'];
  config.checktoken = {
    ignore: ['/login']
  };
  config.checkuser = {
    ignore: ['/login']
  };
  config.checkauth = {
    ignore: ['/login', '/getUserAclCodes']
  };

  config.security = {
    csrf: false
  };

  config.pageSize = 10;

  config.sequelize = {
    dialect: 'mysql',
    host: '172.16.6.252',
  };
};
