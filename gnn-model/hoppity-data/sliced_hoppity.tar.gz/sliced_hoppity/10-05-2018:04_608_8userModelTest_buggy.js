import UserModel from '../server/api/models/userModel';
describe('User Model', () => {
  const user = new UserModel();
  it('takes in proper paramaters', () => {
    expect(user).to.have.property('rank');
  });
});
