import React from 'react';
const EventList = ({
  events
}) => {
  return React.createElement("div", {
  }, events.length < 1 && React.createElement("p", {
  }, "There are no events currently."), events && events.map(event => {
  }));
};
