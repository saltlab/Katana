var model_1 = require("../model");
var Loader = /** @class */ (function () {
    function Loader(structure, frontMatter) {
        this.structure = structure;
    }
    Loader.prototype.load = function (config) {
        return this.structure.scan(config)
            .then(function (specialDirs) {
            var paramorph = new model_1.Paramorph(config);
            specialDirs.includes.forEach(function (file) { return paramorph.addLayout(new model_1.Include(file.name, file.path)); });
        });
    };
}());
