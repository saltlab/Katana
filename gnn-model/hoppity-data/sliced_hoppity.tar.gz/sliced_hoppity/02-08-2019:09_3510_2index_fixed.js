import Router from 'vue-router'
export default new Router({
  routes: [
    {
      name: 'Home',
    },
  ]
})
