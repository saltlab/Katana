import CheckSessionRoute from '../check-session-route';
import { inject as service } from '@ember/service';
export default CheckSessionRoute.extend({
  currentUser: service(),

  model() {
    const user = this.get('currentUser.user');
  },
});
