import axios from '@/libs/api.request'
export default {
  load: (id) => {
    return axios.get('/merchant/shop/application/one/params/' + id)
  },
}
