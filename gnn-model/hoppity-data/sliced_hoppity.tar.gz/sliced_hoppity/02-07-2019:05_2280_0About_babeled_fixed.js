import React, { Component } from 'react';
class About extends Component {
  render() {
    return React.createElement("div", {
      className: "App"
    }, React.createElement("header", {
      className: "App-header"
    }, React.createElement("p", null, "Edit ", React.createElement("code", null, "src/App.js"), "ABOUT"), React.createElement("a", {
      className: "App-link",
      href: "https://reactjs.org",
      target: "_blank",
      rel: "noopener noreferrer"
    }, "Learn React")));
  }
}
