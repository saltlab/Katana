export default {
  module: {
    rules: [
      {
        exclude: /node_modules/,
      },
    ],
  },
};
