import React, { Component } from 'react';
import ApolloClient from 'apollo-boost';
import BookList from './components/BookList';
import NewBookForm from './components/NewBookForm';
const client = new ApolloClient({
});
class App extends Component {
  render() {
    return React.createElement(ApolloProvider, {
      client: client
    }, React.createElement("div", {
      id: "main"
    }, React.createElement("h1", null, "Hello Fancy Apptitude"), React.createElement(BookList, null)), React.createElement("div", {
      className: "new-book-input"
    }, React.createElement(NewBookForm, null)));
  }
}
