const styles = {
  root: {
    flexGrow: 1
  },
  grow: {
    flexGrow: 1
  },
  color: {
    backgroundColor: "#282829"
  },
  links: {
    textDecoration: "none",
    color: "white"
  }
};
