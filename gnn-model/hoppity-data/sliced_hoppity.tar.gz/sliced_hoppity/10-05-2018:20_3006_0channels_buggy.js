const logger=require('./logger')
module.exports = function(app) {
  if(typeof app.channel !== 'function') {
    // If no real-time functionality has been configured just return
    logger.debug("no channel")
    return;
  }

  app.on('connection', connection => {
    // On a new real-time connection, add it to the anonymous channel
    app.channel('anonymous').join(connection);
    logger.debug("connection "+JSON.stringify(connection))
  });

  app.on('login', (authResult, { connection }) => {
    logger.info("user logged in, opened channel")
  });
};
