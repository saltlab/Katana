const logger = require('./hooks/logger');
const { validateRouteId } = require('./hooks/params');
const basicParams = () => (context) => {
  if (!context.params) {
    context.params = {};
  }
  if (!context.params.query) {
    context.params.query = {};
  }
};
const hooks = {
  before: {
    all: [
      validateRouteId(),
    ],
    find: [
      basicParams(),
    ],
    get: [
      basicParams(),
    ],
    create: [
      basicParams(),
    ],
    update: [],
    patch: [],
    remove: [],
  },

  after: {
    all: [logger()],
    find: [],
    get: [],
    create: [],
    update: [],
    patch: [],
    remove: [],
  },

  error: {
    all: [],
    find: [],
    get: [],
    create: [],
    update: [],
    patch: [],
    remove: [],
  },
};
