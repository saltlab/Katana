import React from "react";
import axios from "axios";
class HouseKeeping extends React.Component {
  componentDidMount() {
    axios.get("/vendor/house-keeping").then(res => {
    });
  }
}
