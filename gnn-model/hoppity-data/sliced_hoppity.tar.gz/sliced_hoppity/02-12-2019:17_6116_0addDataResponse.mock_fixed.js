import sinon from 'sinon';
export const dataResponses = { store: sinon.spy(), safeFetch: sinon.stub() };
