export default {
  validData2: {
    name: 'All party',
  },
};
