module.exports = {
  siteMetadata: {
    title: `Get Best Offers`,
    description: `Subscribe today and get the lastest health offers, wealth offers, and relationship offers`,
    author: `@getbestoffers`,
  },
  plugins: [
    {
      resolve: `gatsby-plugin-hotjar`,
      options: {
        id: '1194868',
      },
    },
  ],
}
