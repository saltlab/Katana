import React from 'react';
import FieldSelector from '../FieldSelector/FieldSelector';
const AllFields = props => {
  return React.createElement("div", null, React.createElement(FieldSelector, {
  }), React.createElement(FieldSelector, {
    kind: "Dropdown Input"
  }));
};
