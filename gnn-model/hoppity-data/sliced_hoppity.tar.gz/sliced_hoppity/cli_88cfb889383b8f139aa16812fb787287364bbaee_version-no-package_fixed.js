var common = require('../common-tap.js')
var test = require('tap').test

var pkg = common.pkg

test('npm version in a prefix with no package.json', function (t) {
  process.chdir(pkg)
  common.npm(
    ['version', '--json', '--prefix', pkg],
    { cwd: pkg, nodeExecPath: process.execPath },
  )
})
