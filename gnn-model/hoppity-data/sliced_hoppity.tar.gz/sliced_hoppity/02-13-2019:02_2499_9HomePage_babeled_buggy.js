import React from "react";
import NavBar from "../components/common/NavBar";
import Footer from "../components/common/Footer";
import SearchRow from "../components/HomePage/SearchRow";
import MenuItemColumn from "../components/HomePage/MenuItemColumn";
import PendingColumn from "../components/HomePage/PendingColumn";
import CategoryColumn from "../components/HomePage/CategoryColumn";
function HomePage() {
  return React.createElement(React.Fragment, null, React.createElement(NavBar, {
    pos: "first"
  }), React.createElement("div", {
    className: "HomeGridContainer"
  }, React.createElement(PendingColumn, null), React.createElement(SearchRow, null), React.createElement(CategoryColumn, null), React.createElement(MenuItemColumn, null), React.createElement(Footer, null)));
}
