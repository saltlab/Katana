import baseConfig from "./../../config";
import colorPlane from "./../../../components/ColorPlane/config";
export default baseConfig.extends({
  micro: {
    colorPlane: colorPlane.extends({
      color: new THREE.Color("rgb(44, 48, 55)")
    }),
  },
})
