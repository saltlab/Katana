const rawEnv = require('./compiled_env.json');
const env = (envName, defaultVal) => {
  if (!rawEnv[envName] && !defaultVal) { throw new Error(`Must Specify '${envName}'!`); }
};
export const DST_PATH = 'dst';
export const GOOGLE_ANALYTICS = env('GOOGLE_ANALYTICS', 'null') !== 'null' ? env('GOOGLE_ANALYTICS') : '';
