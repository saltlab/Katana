import React from 'react';
const About = () => {
  return React.createElement("div", {
    className: "tc"
  }, React.createElement("div", {
    className: "pa3 pa4-ns",
    "data-name": "slab-stat-small"
  }, React.createElement("h3", {
    className: "f6 ttu tracked"
  }, "Today"), React.createElement("div", {
    className: "cf"
  }, React.createElement("dl", {
    className: "fl fn-l w-50 dib-l w-auto-l lh-title mr5-l"
  }, React.createElement("dd", {
    className: "f6 fw4 ml0"
  }, "Cities"), React.createElement("dd", {
    className: "f3 fw6 ml0"
  }, "50,000+")), React.createElement("dl", {
    className: "fl fn-l w-50 dib-l w-auto-l lh-title mr5-l"
  }, React.createElement("dd", {
    className: "f6 fw4 ml0"
  }, "Countries"), React.createElement("dd", {
    className: "f3 fw6 ml0"
  }, "165")), React.createElement("dl", {
    className: "fl fn-l w-50 dib-l w-auto-l lh-title mr5-l"
  }, React.createElement("dd", {
    className: "f6 fw4 ml0"
  }, "Continents"), React.createElement("dd", {
    className: "f3 fw6 ml0"
  }, "7")), React.createElement("dl", {
    className: "fl fn-l w-50 dib-l w-auto-l lh-title mr5-l"
  }, React.createElement("dd", {
    className: "f6 fw4 ml0"
  }, "Possibilities"), React.createElement("dd", {
    className: "f3 fw6 ml0"
  }, "\u221E")), React.createElement("dl", {
    className: "fl fn-l w-50 dib-l w-auto-l lh-title mr5-l"
  }, React.createElement("dd", {
    className: "f6 fw4 ml0"
  }, "Favorite Place"), React.createElement("dd", {
    className: "f3 fw6 ml0"
  }, "All of Them")), React.createElement("dl", {
    className: "fl fn-l w-50 dib-l w-auto-l lh-title"
  }, React.createElement("dd", {
    className: "f6 fw4 ml0"
  }, "App Downloads"), React.createElement("dd", {
    className: "f3 fw6 ml0"
  }, "1,200")))));
};
