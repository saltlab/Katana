const Koa = require("koa")
const app = new Koa();
const SERVER_PORT = 3456;
app.listen(SERVER_PORT, () => {
  console.log(`[Money Pro Chart] Server is running on the port ${SERVER_PORT}!`);
});
