import React from 'react';
function SingerAvatar(props) {
  const {
    classes,
    song,
    singerName
  } = props;
  let cover = classes.coverNotYou;
  if (song && song.singer === singerName) cover = classes.coverYou;
  return React.createElement("div", {
    className: cover
  }, React.createElement(Typography, {
    variant: "h1",
    className: classes.letter
  }, song && song.singer && song.singer.length > 0 ? song.singer.charAt(0).toUpperCase() : '♪'));
}
