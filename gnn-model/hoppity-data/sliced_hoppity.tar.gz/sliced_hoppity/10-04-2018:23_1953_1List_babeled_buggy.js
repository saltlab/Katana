import React, { Component } from 'react';
import Element from './Element';
class List extends Component {
  render() {
    const pokeList = this.props.pokemonInfo.map((pokemon, index) => {
      return React.createElement("li", {
      }, React.createElement(Element, {
        type: pokemon.type.map(types => types.type.name)
      }));
    });
  }
}
