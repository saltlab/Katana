const router = require('express').Router();
const nodemailer = require('nodemailer');
router.post('/', (req, res) => {
  const phone = req.body.phone;
  const mail = {
    from: '"Perfect Partner" <perfect_partner1@outlook.com>',
    to: `${phone}@textmagic.com`,
    subject: 'Hello ✔',
    text: 'Tell her you love her.'
  };
  const transporter = nodemailer.createTransport({
  });
  transporter.sendMail(mail, (err, data) => {
    if (err) {
      res.json({
        msg: 'Fail'
      });
      return console.log(error);
    } else {
      console.log('Message sent: %s', data.messageId);
      console.log('Preview URL: %s', nodemailer.getTestMessageUrl(data));
      res.json({
        msg: 'Success'
      });
    }
  });
});
