const express = require('express')
const interesado = require('../controllers/interesadoController')
const router = express.Router()
router.put('/protegido/cuidados/:protegido_id', interesado.addCiudados)
