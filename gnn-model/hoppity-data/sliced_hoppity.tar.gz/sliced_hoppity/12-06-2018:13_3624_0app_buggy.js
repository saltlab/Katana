var express = require('express');
var campaignRouter = require('./routes/campaign');
var app = express();
app.use('/campaign', campaignRouter);
