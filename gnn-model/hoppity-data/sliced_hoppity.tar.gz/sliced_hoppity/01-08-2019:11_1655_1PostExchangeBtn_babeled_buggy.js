import React from "react";
const PostExchangeBtn = props => {
  return React.createElement("div", {
    className: "exchange-wrapper-btn"
  }, React.createElement("div", null, React.createElement("div", null, React.createElement("a", {
    class: props.className,
    onClick: props.submit,
    "data-open": "passphrase-modal"
  }, props.translate("transaction.swap") || "Swap")), props.rateToken), props.modalPassphrase, props.modalConfirm, props.modalApprove, React.createElement(PendingOverlay, {
    isEnable: props.isConfirming || props.isApproving
  }));
};
