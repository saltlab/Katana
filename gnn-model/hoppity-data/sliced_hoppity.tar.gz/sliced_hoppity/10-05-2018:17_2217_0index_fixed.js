function skipCounting (skipCount, times, startingNumber){
}
function howManyTimes (numberStart, numberEnd) {
}
console.log(Arrays)
