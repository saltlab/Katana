
$.getJSON('https://cdn.jsdelivr.net/gh/highcharts/highcharts@680f5d50a47e90f53d814b53f80ce1850b9060c0/samples/data/world-population-density.json', function (data) {
});
