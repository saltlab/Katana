import React from 'react';
import Helmet from 'react-helmet';
const TagsPage = ({
  data: {
    allMarkdownRemark: {
      group
    },
    site: {
      siteMetadata: {
        title
      }
    }
  }
}) => React.createElement(Layout, null, React.createElement("section", {
  className: "section"
}, React.createElement(Helmet, {
  title: `Tags | ${title}`
}), React.createElement("div", {
  className: "container content"
}, React.createElement("div", {
  className: "columns"
}, React.createElement("div", {
  className: "column is-10 is-offset-1",
  style: {
    marginBottom: '6rem'
  }
}, React.createElement("h1", {
  className: "title is-size-2 is-bold-light"
}, "Tags"), React.createElement("ul", {
  className: "taglist"
}, group.map(tag => React.createElement("li", {
  key: tag.fieldValue
}, React.createElement(Link, {
  to: `/tags/${kebabCase(tag.fieldValue)}/`
}, tag.fieldValue, ' ', "(", tag.totalCount, ")")))))))));
