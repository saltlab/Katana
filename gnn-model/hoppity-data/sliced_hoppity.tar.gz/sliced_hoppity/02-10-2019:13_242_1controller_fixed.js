const fs = require("mz/fs");
const path = require("path");
var addController = function(router,dir){
    var files = fs.readdirSync(dir).filter((f)=>{
        return f.endsWith(".js");
    });
    for(var file of files){
        file = path.join(dir,file);
    }
};
