import { Calendar } from 'styled-icons/feather/Calendar.cjs'
import { Users } from 'styled-icons/feather/Users.cjs'

export const SITE_ROOT = process.env.NODE_ENV == 'production' ? 'https://setblocks.herokuapp.com' : 'http://localhost:3000';
