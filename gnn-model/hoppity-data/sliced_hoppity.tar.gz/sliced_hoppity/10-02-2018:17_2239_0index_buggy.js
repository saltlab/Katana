function destructivelyRemoveFirstKitten() {
}
function appendKitten(name) {
  return kitten.concat(name)
}
