
describe('/', () => {
  describe('challenge "premiumPaywall"', () => {

  })
  describe('challenge "securityPolicy"', () => {
    it('should be able to access the security.txt file', () => {
      browser.driver.get(browser.baseUrl + '/.well-known/security.txt')
    })
  })
})
