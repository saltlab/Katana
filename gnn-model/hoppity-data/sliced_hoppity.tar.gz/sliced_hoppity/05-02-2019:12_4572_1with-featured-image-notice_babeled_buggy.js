export default createHigherOrderComponent(PostFeaturedImage => {
  return props => {
    const {
      media
    } = props;
    const message = !media ? __('Selecting a featured image is recommended for an optimal user experience.', 'amp') : __('The featured image should have a width of at least 1200px.', 'amp');
  };
}, 'withFeaturedImageNotice');
