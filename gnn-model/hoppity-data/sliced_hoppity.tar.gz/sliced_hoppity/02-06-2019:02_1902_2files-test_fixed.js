const load_file = require('./load_file');
describe('files',function(){
	it('basic',function(done){
		var oConfig = load_file( "./files/basic.yml" );
	});
});
