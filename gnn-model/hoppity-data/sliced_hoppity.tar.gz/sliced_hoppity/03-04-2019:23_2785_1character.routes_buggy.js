const express = require('express');
const controller = require('./character.controllers');
const parcel = require('../../middleware/asyncHandler');
const router = express.Router();
router.get('/character/:name', parcel(controller.GetCharacter));
