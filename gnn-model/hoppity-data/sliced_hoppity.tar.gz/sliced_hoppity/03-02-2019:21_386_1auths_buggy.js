module.exports = function(sequelize, DataTypes) {
    var Auths = sequelize.define("Auths", {
        firstName: {
            type: DataTypes.STRING,
            allowNull: false,
            validate: {
                len: [1, 240]
            }
        },

        email: {
            type: DataTypes.STRING,
            allowNull: false
        },
    });
}
