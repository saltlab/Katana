function takeANumber(ppl,name){
  katzDeliLine.append(name);
}
