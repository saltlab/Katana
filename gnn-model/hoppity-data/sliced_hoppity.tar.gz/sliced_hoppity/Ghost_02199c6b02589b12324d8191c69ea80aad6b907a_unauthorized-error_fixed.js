function UnauthorizedError(message) {
    this.statusCode = 401;
}
