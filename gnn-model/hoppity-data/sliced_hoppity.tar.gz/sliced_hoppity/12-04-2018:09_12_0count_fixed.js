$('.count').each(function () {
  if (window.innerWidth >= 600) {
    $(this).prop('Counter',0).animate({
        Counter: $(this).text()
    }, {
        duration: 10000,
    });
  }
});
