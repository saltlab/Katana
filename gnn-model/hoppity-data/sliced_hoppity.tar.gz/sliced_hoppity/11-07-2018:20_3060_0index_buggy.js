function getFirstSelector(selector){
  let result = document.querySelector(selector);
  return result;
}

function nestedTarget(){
  let result = document.getElementById('nested').querySelector('div.target');
  return result;

}

function increaseRankBy(n){
  let result = document.queryselectorAll('.ranked-lists')
  for (let i=0; i<result.length; i++){
}
}
