import React, { Component } from 'react';
class InputField extends Component {
  render() {
    return React.createElement("form", {
    }, React.createElement("input", {
      placeholder: "Enter your school district",
    }));
  }
}
