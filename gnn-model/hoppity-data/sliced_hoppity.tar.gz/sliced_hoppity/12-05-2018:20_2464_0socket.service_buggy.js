import socketIo from 'socket.io-client';
export function connectSocket(token) {
    return new Promise((resolve, reject) => {

        io = socketIo('/', {query: {token: token}}); // пробуем подключится к ноду
    });
}
