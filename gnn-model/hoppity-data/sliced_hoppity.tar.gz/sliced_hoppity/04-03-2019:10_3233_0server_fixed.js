var http = require('http');
var fs = require('fs');
http.createServer((req, res) => {
  fs.readFile(filename, (err, data) => {
   });
  console.log('This was the requested page ' + req.url);
}).listen(8080);
