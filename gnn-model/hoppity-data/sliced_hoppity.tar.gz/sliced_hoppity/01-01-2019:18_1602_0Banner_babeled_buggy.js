import React, { Component } from 'react';
const Banner = () => {
  return React.createElement("div", {
    className: "Banner"
  }, React.createElement("div", {
    className: "banner-center"
  }, React.createElement("img", {
    src: "./images/icecreams.jpg",
    className: "cones-img"
  }), React.createElement("p", null, "Hear directly from the people who know it best. From tech to politics to creativity and more \u2014 whatever your interest, we\u2019ve got you covered.")));
};
