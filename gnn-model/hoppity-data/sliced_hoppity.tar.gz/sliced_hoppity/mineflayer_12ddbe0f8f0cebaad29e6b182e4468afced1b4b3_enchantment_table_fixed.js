const EnchantmentTable = require('../enchantment_table')
const assert = require('assert')
function noop (err) {
}
function inject (bot, { version }) {
  function openEnchantmentTable (enchantmentTableBlock) {
    let ready = false
    const enchantmentTable = bot.openBlock(enchantmentTableBlock, EnchantmentTable)
    enchantmentTable.enchant = enchant
    enchantmentTable.takeTargetItem = takeTargetItem
    enchantmentTable.putTargetItem = putTargetItem
    enchantmentTable.putLapis = putLapis
    function onUpdateWindowProperty (packet) {
      const arr = enchantmentTable.enchantments
      arr[packet.property].level = packet.value
      if (arr[0].level && arr[1].level && arr[2].level && !ready) {
        ready = true
      }
    }
    function resetEnchantmentOptions () {
      enchantmentTable.enchantments = [{
      }]
      ready = false
    }
    function enchant (choice, cb) {
      choice = parseInt(choice, 10) // allow string argument
      cb = cb || noop
      assert.notStrictEqual(enchantmentTable.enchantments[choice].level, null)
    }
  }
}
