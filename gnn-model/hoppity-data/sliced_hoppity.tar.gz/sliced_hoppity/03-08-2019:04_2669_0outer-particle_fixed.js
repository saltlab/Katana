defineParticle(({Particle}) => {
  return class P extends Particle {
    async setHandles(handles) {
      this.arc = await this.constructInnerArc();
      this.inHandle = await this.arc.createHandle(handles.get('input').type, 'input');
    }
    async onHandleSync(handle, model) {
      if (handle.name === 'input' && model) {
        this.inHandle.set(model);
      }
      if (handle.name === 'particle0') {
      }
    }
  };
});
