const configs = {
    https : true,
    live : false,
    remote : false,
    port: 80,
    SSLPORT: 443,
    domain: 'afterdarksg.com'
}
