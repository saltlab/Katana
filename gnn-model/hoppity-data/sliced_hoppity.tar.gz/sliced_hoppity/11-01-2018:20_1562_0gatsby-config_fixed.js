const lost = require('lost')
const pxtorem = require('postcss-pxtorem')

module.exports = {
  siteMetadata: {
    url: 'https://www.protocolsforhumanity.org',
    title: 'Protocols for Humanity',
    subtitle:
      'Developing protocols that support access to basic needs for all humans.',
    copyright: 'CC-BY-SA',
    disqusShortname: '',
    menu: [
      {
        label: 'Articles',
        path: '/',
      },
      {
        label: 'About',
        path: '/about/',
      },
    ],
    author: {
      name: 'Protocols for Humanity',
      email: '#',
      telegram: '#',
      twitter: 'https://twitter.com/Protocols4Human',
    },
  },
}
