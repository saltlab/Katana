const postsSeed = [
    {
        username_posted: "happy",
    },
];
