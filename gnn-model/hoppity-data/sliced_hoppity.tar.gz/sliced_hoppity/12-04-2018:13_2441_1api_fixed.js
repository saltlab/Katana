export default {
  getLandingsList () {
    return new Promise((resolve) => {
      resolve([
        {
          slug: 'Hero',
          theme: {
            sections: ['HeroUnit']
          }
        },
      ])
    })
  },
}
