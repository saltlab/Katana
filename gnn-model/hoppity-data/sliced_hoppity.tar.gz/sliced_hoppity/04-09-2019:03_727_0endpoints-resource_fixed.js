const bundle = createAsyncResourceBundle({
})
bundle.reactEndpointsResourceFetch = createSelector(
)
