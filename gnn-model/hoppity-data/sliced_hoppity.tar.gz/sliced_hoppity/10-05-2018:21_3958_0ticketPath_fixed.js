const data = {
  "lvl1":[
    //todo
    {"ebook":"- Student is unable to access their eBook.", "nextChoice1":"PDF", "nextChoice2":"Web Viewer" },
    {"passreset":"- Student is unable to access their account.", "nextChoice1":"Regestered", "nextChoice2":"Not Regestered"}
  ],
  "lvl2":[
    //todo
    {"PDF":"- Student is unable to access their eBook.", "nextChoice1":"???", "nextChoice2":"???" },
    {"Web Viewer":"- Student is unable to access their account.", "nextChoice1":"???", "nextChoice2":"???"},
    {"Regestered":"- Student is regestered.", "nextChoice1":"???", "nextChoice2":"???" },
    {"Not Regestered":"- Student is not regestered.", "nextChoice1":"???", "nextChoice2":"???"}
  ]
};
var path = JSON.parse(data);
