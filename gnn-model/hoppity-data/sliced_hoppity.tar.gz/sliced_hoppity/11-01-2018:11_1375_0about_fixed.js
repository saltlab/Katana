message.channel.send({
	embed: {
		footer: {
			text: "v2.2.0 | " + client.guilds.size + "G, " + client.channels.size + "C, " + client.users.size + "U | Commit " + commid + " | by @rx#0611 using discord.js"
		}
	}
});
