import db                          from "../../helpers/database";
async function get(req, res) {
    const client     = await db.connect();
}
export { get };
