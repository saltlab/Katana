import PropTypes from 'prop-types';
const Dashboard = props => {
};
Dashboard.propTypes = {
  activePageHeader: PropTypes.string.isRequired
};
