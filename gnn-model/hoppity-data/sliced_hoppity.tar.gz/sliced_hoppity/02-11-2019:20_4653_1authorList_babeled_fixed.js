var React = require('react');
var Router = require('react-router');
var Link = Router.Link;
var AuthorList = React.createClass({
  render: function () {
    var createAuthorRow = function (author) {
      return React.createElement("tr", {
        key: author.id
      }, React.createElement("td", null, React.createElement(Link, {
        to: "editAuthor",
        params: {
          authorId: author.id
        }
      }, author.id)), React.createElement("td", null, author.firstName, " ", author.lastName));
    };
  }
});
