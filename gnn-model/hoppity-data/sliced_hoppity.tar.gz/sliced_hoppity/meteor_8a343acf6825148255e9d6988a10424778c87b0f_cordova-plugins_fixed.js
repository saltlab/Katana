var selftest = require('../selftest.js');
var Sandbox = selftest.Sandbox;
selftest.define("change cordova plugins", function () {
  var s = new Sandbox();
  var run;
  run = s.run();
  run.match("exact version");
});
