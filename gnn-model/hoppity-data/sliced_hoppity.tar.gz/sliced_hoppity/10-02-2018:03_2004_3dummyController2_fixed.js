module.exports = {
  mw1: (req, res, next) => {
    console.log('running mw1 => (Controller 2)');
    setTimeout(() => next(), 34)
  },
}
