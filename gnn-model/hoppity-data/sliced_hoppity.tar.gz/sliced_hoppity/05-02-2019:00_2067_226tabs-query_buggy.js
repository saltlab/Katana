const Tabs = require('../tabs')
var WorkspaceContentTabs = Tabs.extend({
})
