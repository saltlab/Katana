const path = require('path')
const config = {
  entry: {
    app: './src/scripts/app/App.tsx',
  },
  output: {
    path: path.resolve(__dirname, 'dist/static'),
    filename: '[name].citadel.js',
  },
  resolve: {
    extensions: ['.ts', '.tsx', '.js', '.json'],
  },
  module: {
    rules: [
      {
        test: /\.tsx?$/,
        exclude: /node_modules/,
        loader: 'ts-loader',
        options: {
          configFile: 'tsconfig.json',
        },
      },
    ],
  },
}
