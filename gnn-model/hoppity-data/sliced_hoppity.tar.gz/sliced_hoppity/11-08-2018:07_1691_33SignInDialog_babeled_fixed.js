import React from "react";
import Button from "@material-ui/core/Button";
import Dialog from "@material-ui/core/Dialog";
import DialogActions from "@material-ui/core/DialogActions";
import DialogContent from "@material-ui/core/DialogContent";
import DialogTitle from "@material-ui/core/DialogTitle";
import Typography from "@material-ui/core/Typography";
class SignInDialog extends React.PureComponent {
  render() {
    return React.createElement(Dialog, {
    }, React.createElement(DialogTitle, null, "Sign in Request"), React.createElement(DialogContent, null, React.createElement(Typography, null, "To save your work on this activity, please log in")), React.createElement(DialogActions, null, React.createElement(Button, {
      variant: "contained"
    }, "Sign in")));
  }
}
