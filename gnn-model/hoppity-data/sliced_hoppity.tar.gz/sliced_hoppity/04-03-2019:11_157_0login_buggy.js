const bcrypt = require('bcrypt');
const db = require('../modules/db');
const express = require('express');
const router = express.Router();
router.post('/', async (req, res) => {
        let member = await db.getMemberByEmail(req.body.email);
        const isValid = await bcrypt.compare(req.body.password, member.password);
});
