import axios from "axios";
export default {
    saveEntry: function(entryData) {
      return axios.post("/entries/api/entry", entryData);
    },
  };
