"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.VERSION = '^2.0.0-rc.2-f9130c7';
