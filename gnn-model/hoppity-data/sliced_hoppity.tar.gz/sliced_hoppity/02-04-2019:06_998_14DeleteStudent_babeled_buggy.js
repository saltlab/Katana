import React, { Component } from "react";
class DeleteStudent extends Component {
  getOptions(student) {
    if (!student) {
      return React.createElement("div", null, "loading...");
    }
  }
}
