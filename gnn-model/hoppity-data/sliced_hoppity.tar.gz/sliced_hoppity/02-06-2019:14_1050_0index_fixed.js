function dec(n) { return (n - 1) }
function makeInt(n) { parseInt(n, 10) }
