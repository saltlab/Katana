exports.run = (client, msg, args) => {
    let undyneclarke = "319464149325447168"
    if (msg.author.id !== undyneclarke) return;

    else {
        const fs = require("fs")
        let [format, file] = args.join(" ").split(" | ")

        fs.readFile(file, (err, data) => {
            if (err) msg.channel.send(`Failed. Showing the error: \`\`\`${err}\`\`\``)
            msg.channel.send(`\`\`\`${format}\n${data}\`\`\``)
        });
    }
}
exports.help = {
    'help': {
      name: 'readfile',
      description: "Reads a file",
      category: 'Development',
      usage: '/readfile <format> | <path>',
    },
  };
