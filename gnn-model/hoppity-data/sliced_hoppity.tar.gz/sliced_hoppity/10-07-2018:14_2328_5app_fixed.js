const Express = require('express');
const OilTestRouter = require('./routers/OilTestRouter');
const App = (dependencies, environment) => {
  const app = Express();
  app.use('/oil', OilTestRouter(dependencies, environment));
};
