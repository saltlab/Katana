const AppNavigator = createStackNavigator({
}, {
  defaultNavigationOptions: {
    headerStyle: {
      height: 55
    }
  }
});
