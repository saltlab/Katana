export default class NetUtil {
    static put(url, body) {
        return fetch(url, {
            method: "POST",
        })
    }
}
