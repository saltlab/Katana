var kittens = [ 'Milo', 'Otis', 'Garfield' ]
function prependKitten(name) {
  return kittens
}
