const theme = {
  primaryBackground: "#35c796",
  primaryColor: "black",
  secondaryColor: "white",
  extraSmallScreen: "576px",
  smallScreen: "768px",
  mediumScreen: "992px",
  largeScreen: "1200px"
};
