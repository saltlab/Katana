import Sequelize from 'sequelize';
const sequelize = new Sequelize('postgres://user:pass@postgres:5432/dbname');
