import shader from "shader";
export const blue_light = shader(blue, 0.85);
