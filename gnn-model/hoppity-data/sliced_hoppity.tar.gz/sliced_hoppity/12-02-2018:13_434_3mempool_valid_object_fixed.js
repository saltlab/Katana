class MempoolValidObject {
    constructor(walletAddress) {
        this.status = {
            message: "TODO add message",
        };
    }
}
