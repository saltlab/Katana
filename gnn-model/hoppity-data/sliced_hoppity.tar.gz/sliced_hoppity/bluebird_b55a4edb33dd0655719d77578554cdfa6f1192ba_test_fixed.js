function needsFreshProcess(testName) {
    return /domain|schedule|api_exceptions|promisify/.test(testName);
}
