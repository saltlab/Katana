define('ext.wikia.adEngine.tracking.nielsen', [
], function (
	pageLevelParams,
) {
	function call() {
		const pageParams = pageLevelParams.getPageLevelParams();
	}
});
