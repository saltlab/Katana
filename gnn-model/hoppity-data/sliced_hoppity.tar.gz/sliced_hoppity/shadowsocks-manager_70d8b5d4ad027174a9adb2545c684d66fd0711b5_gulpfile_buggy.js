const gulp = require('gulp');
gulp.task('freeAccountCopy', ['freeAccountBuild'], () => {
  return gulp.src(['plugins/freeAccount/libs/**', 'plugins/freeAccount/public/**'], {
    base: './'
  }).pipe(gulp.dest('lib'));
});
