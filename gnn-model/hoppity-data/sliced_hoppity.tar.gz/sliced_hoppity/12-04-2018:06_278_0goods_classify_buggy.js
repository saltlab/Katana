var goods_classifyObj = {
  name: 'goods_classify',
  init: function() {
    console.log(this.name);
    this.goPage();
    var str = '';
    for (var i = 0; i < 10; i++) {
      str += '<li onclick="goods_classifyObj.changeSelect(' + "this" +', '+ `${i}` +')">' +
      '<span>公司车型'+ i +'</span>' +
    '</li>'
    }
    $('.list_left').html(str);
    this.changeSelect($('.list_left li:first-child'), '初始值');
    this.changeType($('.list_type li:first-child'), '初始值2');
  },
  changeSelect: function(that, type) {
    $(that).find('span').addClass('select').parent().siblings().find('span').removeClass('select');
    console.log(type);
  },
  changeType: function(that, type) {
    $(that).find('span').addClass('select').parent().siblings().find('span').removeClass('select');
    console.log(type);
  },
  goPage: function() { // 跳转页面
    this.goPageFun('#home', 'index.html');
    this.goPageFun('#about', 'about.html');
    this.goPageFun('#video', 'video.html');
    this.goPageFun('#owner', 'owner.html');
    this.goPageFun('#picture', 'picture.html');
  },
  goPageFun: function(dom, page) { // 跳转页面方法
    $(dom).click(function() {
      window.location.href = page;
    })
  }
}
