const styles = theme => ({
  root: {
    [theme.breakpoints.up('md')]: {
      padding: theme.spacing.unit * 8
    }
  },
});
