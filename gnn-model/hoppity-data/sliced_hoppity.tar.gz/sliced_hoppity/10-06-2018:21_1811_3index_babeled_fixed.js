import React from "react";
export class NavBar extends React.Component {
  constructor(props) {
    this.state = {
      pages: ["Home", "Editorial", "Shop", "About", "Cart"]
    };
  }
}
