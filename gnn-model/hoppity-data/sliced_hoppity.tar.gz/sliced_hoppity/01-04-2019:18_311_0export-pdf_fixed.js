const puppeteer = require('puppeteer');
async function generatePdf(id, format = 'Tabloid', landscape = true) {
  const browser = await puppeteer.launch({
    args: ['--headless', '--disable-setuid-sandbox', '--no-sandbox', 'disable-gpu'],
  });
}
