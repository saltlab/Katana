var Sequelize = require('sequelize');
var sequelize = new Sequelize('quickbulletin', 'postgres', 'CATS@myhouse', {
    host: 'localhost',
    dialect: 'postgres'
});
