    utils      = require("./lib/utils.js"),
    paths      = require("./lib/paths"),
    cfg        = require("./lib/cfg.js"),
    async      = require("async"),
    config     = null,
function init(home, options, isStandalone, callback) {
    if (isStandalone) printLogo();
    if (typeof home === "string") {
        paths.home  = utils.resolve(home);
        paths.files = utils.resolve(home + "/files");
        paths.cfg   = utils.resolve(home + "/config/config.json");
        paths.db    = utils.resolve(home + "/config/db.json");
    }
    async.series([
        function (cb) { cfg.init(options, function (err, cfg) { config = cfg; cb(err); }); },
    ], function (err, result) {
        if (err) return callback(err);
        if (isStandalone) startListener(config.useTLS && result[5]);
    });
}
