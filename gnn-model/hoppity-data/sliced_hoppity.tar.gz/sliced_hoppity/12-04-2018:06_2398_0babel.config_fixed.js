module.exports = {
  cacheDirectory: true,
  presets: [
    '@babel/preset-react',
    [
      '@babel/preset-env',
      {
        useBuiltIns: 'usage',
        targets: {
          browsers: ['ios >= 7', 'android >= 4.4']
        },
        modules: 'commonjs'
      }
    ]
  ],
  plugins: [
    '@babel/plugin-transform-runtime',
    '@babel/plugin-proposal-object-rest-spread',
    [
      'import',
      {
        libraryName: 'auto-ui',
        libraryDirectory: 'es',
        style: true
      }
    ],
    [
      'react-css-modules',
      {
        generateScopedName: '[local]_[hash:base64:6]',
        filetypes: {
          '.mcss': {
            syntax: 'postcss-scss'
          }
        },
        handleMissingStyleName: 'ignore'
      }
    ],
    '@babel/plugin-syntax-dynamic-import',
    '@babel/plugin-syntax-import-meta',
    [
      '@babel/plugin-proposal-decorators',
      {
        legacy: true
      }
    ],
  ]
}
