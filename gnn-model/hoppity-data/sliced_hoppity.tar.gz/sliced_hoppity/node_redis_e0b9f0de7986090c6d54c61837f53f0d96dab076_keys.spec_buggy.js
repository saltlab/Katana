var config = require("../lib/config");
var helper = require("../helper");
var redis = config.redis;
describe("The 'keys' method", function () {
    helper.allTests(function(parser, ip, args) {
        describe("using " + parser + " and " + ip, function () {
            var client;
            beforeEach(function (done) {
                args = args || {};
                args.command_queue_high_water = 100;
                client = redis.createClient.apply(redis.createClient, args);
                client.once("connect", function () {
                });
            });
        });
    });
});
