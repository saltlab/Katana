//  OpenShift sample Node application
var express = require('express'),
    app     = express(),
    morgan  = require('morgan');

Object.assign=require('object-assign')
//var mongoose = require('mongoose');
//var passport = require('passport');
//var bodyParser = require('body-parser');
var configDB = require('./config/database.js');
var ip = process.env.IP   || process.env.OPENSHIFT_NODEJS_IP || '0.0.0.0';
