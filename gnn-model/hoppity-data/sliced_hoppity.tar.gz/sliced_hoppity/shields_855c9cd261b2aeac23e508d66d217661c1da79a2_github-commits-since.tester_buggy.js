'use strict'

const Joi = require('joi')

const t = (module.exports = require('..').createServiceTester())
