class App extends Component {
  constructor(props) {
    this.updateWindowDimensions = this.updateWindowDimensions.bind(this);
  }
  updateWindowDimensions() {
  }
  componentDidMount() {
    fetch("http://localhost:9090/api/channel").then(response => response.json()).then(data => this.setState({
    }));
  }
}
