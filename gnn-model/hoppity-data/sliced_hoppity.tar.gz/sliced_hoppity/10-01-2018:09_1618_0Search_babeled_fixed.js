import React from "react";
const Search = props => {
  const {
    algolia
  } = props;
  return React.createElement("div", {
  }, algolia && algolia.appId && React.createElement(InstantSearch, {
  }, React.createElement(SearchBox, {
    translations: {
      placeholder: "Search Content"
    }
  }), React.createElement(Stats, null), React.createElement(Hits, {
  }), React.createElement(Pagination, null)));
};
