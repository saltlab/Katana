$('#form-contact').addEventListener('submit', function(e) {
  // Store form field values
  var name = $("input[name=name]").value;
  var subject = $("input[name=_subject").value;
  // AJAX request
  var request = new XMLHttpRequest();
  var data = {
    name:name,
    _replyto:email,
    email:email,
    _subject:subject,
    message:message,
  };
  request.setRequestHeader('{{ if .Site.Params.ajaxFormspree }}Content-Type{{ else if .Site.Params.ajaxBasin }}Accept{{ end }}', 'application/json; charset=UTF-8');
});
