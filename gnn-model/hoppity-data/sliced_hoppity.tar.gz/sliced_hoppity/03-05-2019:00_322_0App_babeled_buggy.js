import React, { Component } from 'react';
import logo from './logo.svg';
import { BrowserRouter as Router, Route, Link } from 'react-router-dom';
import OtherPage from './OtherPage';
import Fib from './Fib';
class App extends Component {
  render() {
    return React.createElement(Router, null, React.createElement("div", {
      className: "App"
    }, React.createElement("header", {
      className: "App-header"
    }, React.createElement("img", {
      src: logo,
      className: "App-logo",
      alt: "logo"
    }), React.createElement("h1", {
      className: "App-title"
    }, "Fib Calculator v2"), React.createElement(Link, {
      to: "/"
    }, "Home"), React.createElement(Link, {
      to: "/otherpage"
    }, "Other Page")), React.createElement("div", null, React.createElement(Route, {
      exact: true,
      path: "/",
      component: Fib
    }), React.createElement(Route, {
      path: "/otherpage",
      component: OtherPage
    }))));
  }
}
