import React, { Component } from "react";
class RenderedPortfolio extends Component {
  render() {
    const investments = this.props.portfolio.map((investment, index) => React.createElement("div", {
    }, investment.label, ": ", investment.amountBought.toString(), " *", " ", investment.priceBought.toString()));
  }
}
