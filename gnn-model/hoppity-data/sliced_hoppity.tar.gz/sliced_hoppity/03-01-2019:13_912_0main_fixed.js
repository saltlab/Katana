import Vue from 'vue'
import VueAuthenticate from 'vue-authenticate'
Vue.use(VueAuthenticate, {
  providers: {
    google: {
      redirectUri: 'http://goggle-auth-platform.otterly.cc/oauth_callback',
    }
  }
})
