const db = require('../config/db');
const Vuelo = db.define('Vuelo', {
    CodigoIATADestino: {
        references: {
            key: 'ID'
        },
    },
    });
