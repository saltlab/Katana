var express = require('express');
var router = express.Router();
const webhooks = '';
router.post('/', (req, res) => {
	webhooks = JSON.stringify(req.body);
});
