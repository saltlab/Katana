export default {
  fields: [
    {
      size: 'medium',
    },
  ],
}
