exports.fcsendmail = function(from, to, subject ,message, attachfile){

		var nodemailer = require('nodemailer');

		var transporter = nodemailer.createTransport({
			host: 'smtp.ionos.fr',
			port: 25,
			secure:false,
			  auth: {
				user: 'stephane.tekam@netinafrica.com',
				pass: ''
			  }
			});
	};
