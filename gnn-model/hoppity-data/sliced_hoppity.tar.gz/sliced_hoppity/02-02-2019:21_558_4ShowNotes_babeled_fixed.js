import React, { Component } from 'react';
import NotePreview from './NotePreview';
import NavBar from './NavBar';
class ShowNotes extends Component {
  constructor(props) {
    this.state = {
      notes: []
    };
  }
  render() {
    return React.createElement("div", {
    }, React.createElement("div", {
    }, React.createElement(NavBar, null), React.createElement("div", {
    }, this.state.notes.map(note => React.createElement(NotePreview, {
      key: note._id,
    })))));
  }
}
