import Component from '@ember/component';
export default Component.extend({
  getModelTitle: task(function * () {
    let card = this.model;
    let title = yield this.cardstackData.getCardMetadata(card, 'title');
    this.set('title', title || 'Untitled');
  }).on('init'),
});
