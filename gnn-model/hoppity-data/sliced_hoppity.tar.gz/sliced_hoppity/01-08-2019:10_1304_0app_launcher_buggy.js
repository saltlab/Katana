screens.app.launcher = function AppLauncher(me) {
    me.launch = async function () {
        let config = await me.core.util.config();
    };
    me.html = function () {
        return __html__;
    };
    me.resIcon = async function (object, value) {
        var name = null, extension = null, label = null;
    };
};
