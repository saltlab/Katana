var config = {
    apiKey: "AIzaSyA1CRSWnlG1cwcqVTSOJDTuWY7vW5OMf90",
    authDomain: "bored-project.firebaseapp.com",
    databaseURL: "https://bored-project.firebaseio.com",
    projectId: "bored-project",
    storageBucket: "bored-project.appspot.com",
    messagingSenderId: "232954052621",

    clientId: "42862000042-vrga0sd70rjum6q9sa2c36fcbfoohjvk.apps.googleusercontent.com"
};
var uiConfig = {
    signInSuccessUrl: "./index.html", // Assuming you are running on your local machine
    signInOptions: [
        {
            provider: firebase.auth.GoogleAuthProvider.PROVIDER_ID,
            scopes: config.scopes
        }
    ],
    // Terms of service url.
    tosUrl: "<your-tos-url>"
};
