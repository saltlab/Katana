const express = require('express')
const { join } = require("path")
const Legacy = express.Router()
Legacy.use("/l", express.static(join(__dirname, "legacy")))
