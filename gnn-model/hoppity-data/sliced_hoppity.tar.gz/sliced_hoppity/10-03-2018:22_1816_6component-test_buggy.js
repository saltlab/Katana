module('Integration | Component | rootcause-dimensions-algorithm', function(hooks) {
  test('it renders', async function(assert) {
    this.setProperties({
      metricUrn: 'dataset1:metric1:12345',
    });
  });
});
