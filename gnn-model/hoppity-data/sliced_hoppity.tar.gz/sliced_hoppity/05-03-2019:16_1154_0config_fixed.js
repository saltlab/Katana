module.exports = {
    title: 'Coravel',
    description: 'Near-zero config .NET Core library that makes Task Scheduling, Caching, Queuing, Mailing, Event Broadcasting (and more) a breeze!',
    markdown: {
        toc: {
            includeLevel: [1,2]
        }
    },
}
