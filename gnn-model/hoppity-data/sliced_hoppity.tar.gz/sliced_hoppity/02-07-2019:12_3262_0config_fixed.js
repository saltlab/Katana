var endpoints = {
  transferenceApi: {
    url: process.env.REACT_APP_TRANSFERENCE_API_URL || 'http://localhost:3000/transference/',
    version: 'v1',
    apiKey: ''
  }
};
