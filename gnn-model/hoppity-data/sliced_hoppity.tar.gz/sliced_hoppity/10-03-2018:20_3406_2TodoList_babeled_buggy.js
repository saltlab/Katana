import React from 'react';
const TodoList = props => {
  return React.createElement("div", null, props.todoData.map(item => {
    return React.createElement("h3", null, item.task);
  }));
};
