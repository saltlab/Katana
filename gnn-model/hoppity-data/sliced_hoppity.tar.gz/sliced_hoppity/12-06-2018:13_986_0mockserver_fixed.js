sap.ui.define([
], function (MockServer) {
	return {
		init: function () {
			var oMockServer = new MockServer({
                rootUri: "./localService/mockdata/Invoices.json"
			});
		}
	};
});
