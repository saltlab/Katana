import React from 'react';
import DisplayText from './DisplayText';
it('renders the component with an additional class name', () => {
  const output = mount(React.createElement(DisplayText, {
    extraClassNames: "my-extra-class"
  }, "DisplayText"));
});
