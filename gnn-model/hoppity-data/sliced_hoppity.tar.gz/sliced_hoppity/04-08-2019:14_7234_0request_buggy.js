browser.tabs
  .then(tabs => {
    const { url, id } = tabs[0];
  })
