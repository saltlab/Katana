'use strict'

module.exports = require('./build/src/.prettierrc.json')
