import React, { Component } from 'react';
import BackGroundWrapper from '../components/backGroundWrapper.js';
import Header from '../components/header.js';
export default class WorkoutScreen extends Component {
  render() {
    const {
      workouts
    } = this.state;
    const WOD = workouts.map((exercise, i) => {
    });
    return React.createElement(BackGroundWrapper, null, React.createElement(Header, {
    }), React.createElement(ScrollView, {
      style: {
        marginBottom: 60
      }
    }, WOD));
  }
}
